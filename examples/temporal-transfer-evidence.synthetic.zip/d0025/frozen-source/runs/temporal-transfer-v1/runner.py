"""New lexical domains and two generated pairs; separately approved max12 calls."""
import argparse
import importlib.util
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from runaway import temporal as t, generation
from runaway.card import canonical, digest
from runaway.fidelity_runner import DirectCalls
from runaway.pipeline import write_once
from runaway.selfplay import SYSTEM
from runaway.taste_executor import answers_checked, runtime_check, ORIGINAL_RUN_BOUNDED
from runaway.taste_plan import reader_job

STAGES = {'full_history': 4, 'shared_extraction': 4, 'actual_memory_reader': 4}
ARCHIVES = ('pilot-evidence.synthetic.zip', 'comparison-evidence.synthetic.zip', 'stress-service-evidence.synthetic.zip', 'temporal-evidence.synthetic.zip', 'temporal-scale-evidence.synthetic.zip', 'temporal-discrimination-evidence.synthetic.zip')
read = lambda p: json.loads(Path(p).read_text())


def world_engine(settings):
    # A separate module namespace leaves the original public evaluator untouched.
    spec = importlib.util.spec_from_file_location('runaway._transfer_world_v1', ROOT / 'runaway/fidelity_stress.py')
    engine = importlib.util.module_from_spec(spec); spec.loader.exec_module(engine)
    engine.DOMAINS = tuple((d[0], d[1], tuple(d[2]), tuple(d[3]), tuple(d[4])) for d in settings['domains'])
    engine.EXTRA = {k: (v[0], tuple(v[1])) for k, v in settings['extra'].items()}
    return engine


def source_checks(person, artifact, engine):
    spans = {m[1]: s['id'] for s in artifact['source_spans'] if (m := re.match(r'\s*记录([A-Za-z0-9]+)（', s['text']))}
    events = artifact['extraction']['events']; used = {sid for e in events for sid in e['span_ids']}; by_id = {e['id']: e for e in events}
    edges = []
    for old in person['events']:
        if old['op'] != 'revoke': continue
        found = [e for e in events if e['kind'] == 'retract' and spans[old['id']] in e['span_ids']]
        edges.append(len(found) == 1 and spans[old['target']] in by_id[found[0]['target']]['span_ids'])
    domains = {d[0]: d for d in engine.DOMAINS}; contexts = []
    for case in person['cases']:
        if case['public']['task'] != 'current_choice' or case['order'] != 0 or case['instruction']: continue
        key = case['key']; domain = domains[key][1] if key in domains else engine.EXTRA[key][0]
        context = {domains[key][3][int(k[-1])]: v for k, v in case['context'].items()} if key in domains else {}
        expected = None if case['action'] == 'U' else engine.label(key, case['action'])
        contexts.append(t.resolve(artifact, domain, context)['action'] == expected)
    return {'event_span_coverage': set(spans.values()) <= used, 'retraction_edges': edges, 'current_contexts': contexts}


def prepare(out, runtime, seed=None):
    out = Path(out); out.mkdir(parents=True, exist_ok=False)
    # Protocol/specification is bound before the one-time actual seed is drawn.
    settings_path = ROOT / 'runs/temporal-transfer-v1/domains.json'; settings = read(settings_path)
    specification = {'settings_sha256': hashlib.sha256(settings_path.read_bytes()).hexdigest(), 'stage_caps': STAGES, 'sampling': 'One random seed; fixed two future-mode paired clusters, no model-based selection or resampling.', 'threshold': 'Full current224/224 and history76/76 before any extraction; every extracted source event/edge and27current contexts/person; whole768chars/384tokens. Memory quality reported on all224+76 regardless of success.'}
    write_once(out / 'specification.json', specification)
    engine = world_engine(settings); world = engine.build_world(secrets.randbelow(2**31) if seed is None else seed, 'future')
    assert len(world['people']) == 4 and len({p['pair_id'] for p in world['people']}) == 2
    jobs = []
    for person in world['people']:
        pid = person['id']; public = [c['public'] for c in person['cases']]
        jobs.append({'stage': 'full_history', 'person_id': pid, 'request': reader_job('transfer_full', pid, person['history'], public, engine.READER, 12)['request']})
    for person in world['people']:
        sources = {'schema_version': 1, 'sources': [{'id': 'history', 'episode_id': 'synthetic-lexical-transfer', 'role': 'user', 'text': person['history']}]}
        jobs.append({'stage': 'shared_extraction', 'person_id': person['id'], 'sources': sources, 'request': {'prompt': t.make_request(sources), 'schema': t.SCHEMA, 'model': 'gpt-6-luna', 'system': SYSTEM}})
    write_once(out / 'world.private.json', world); write_once(out / 'jobs.json', jobs); write_once(out / 'domains.json', settings)
    code = [str(p.relative_to(ROOT)) for p in sorted((ROOT / 'runaway').glob('*.py'))] + ['runs/temporal-transfer-v1/runner.py', 'runs/temporal-transfer-v1/test_runner.py', 'runs/temporal-transfer-v1/domains.json']
    inputs = ('specification.json', 'world.private.json', 'jobs.json', 'domains.json')
    body = {'proposal_directory': str(out.resolve()), 'status': 'offline_not_approved_not_executed', 'calls_max': 12, 'stage_caps': STAGES, 'models': {'generator': 'gpt-6-luna', 'reader': 'gpt-6.1-sol'},
        **{k: runtime[k] for k in ('python_executable', 'tokenizer', 'tokenizer_path', 'runtime_expected')},
        'timeout_seconds': 180, 'cleanup_waits_seconds': [2, 2], 'character_budget': 768, 'token_budget': 384,
        'history_characters': sum(len(p['history']) for p in world['people']),
        'selection': 'Four new-to-service synthetic people from one newly drawn seed,2paired units,6new lexical/domain labels. Two complementary3-axis twin contrasts cover all6domains. Finite event grammar is unchanged, not new semantic-task-family or natural-trajectory evidence.',
        'data_scope': 'Only four frozen synthetic histories, actual derived event graphs/current memories,75 public queries/person, required system/schema/CLI metadata. No private parameters/events/gold/context maps, old answers, calibration, real/central/workspace data in payload. Credentials only authenticate.',
        'controls': 'All4 full-source readers are new in this same batch, not reused prior evidence; all must be224/224current+76/76history before any extraction. Prior batches are hash-checked and forbidden, not re-executed or recharged.',
        'gates': 'All source spans/graphs, every event-bearing source line, every retraction edge and27non-instructioncurrent contexts/person; whole768characters/384actualtokens. Any gate, runtime/frozen drift, format/transport/timeout/unknown usage or checkpoint state stops all remaining calls. No repair/truncation/automatic subset/resampling/retry.',
        'reporting': 'Each reader condition224current+76historical=300joint;112collapsed scenarios,6matched domain contrasts,2paired statistical units. Keep all planned denominators, per-pair and critical layers, missing distinct from U. Current-only prompt does not promise history. Strict memory target is224/224current,6/6matched,0hard violations; quality failure reported without extra calls.',
        'cost_boundary': 'Max12 new experiment generations:4full-source readers+4event extractions+4memory readers.180sec+2+2cleanup each. Existing official Codex login/service, unchanged isolation observer, default CLI reasoning, no purchases or old-balance reuse. No aggregate HTTP/token/money/time hard cap.',
        'inference_limit': 'New to this experiment service, same finite grammar and base provider. Not training-independent, naturalistic, real-person, crossprovider, population or significance evidence; only2paired units. No tuning or resampling after service results.',
        'source_hashes': {n: hashlib.sha256((ROOT / n).read_bytes()).hexdigest() for n in code}, 'input_hashes': {n: hashlib.sha256((out / n).read_bytes()).hexdigest() for n in inputs},
        'sealed_archives': {n: hashlib.sha256((ROOT / 'examples' / n).read_bytes()).hexdigest() for n in ARCHIVES},
        'forbidden_request_ids': sorted({Path(n).name.removesuffix('.request.json') for a in ARCHIVES for n in zipfile.ZipFile(ROOT / 'examples' / a).namelist() if n.endswith('.request.json')})}
    p = {**body, 'id': digest(canonical(body))}; write_once(out / 'proposal.json', p)
    for n in code:
        dest = out / 'frozen-source' / n; dest.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(ROOT / n, dest)
    return p


def preflight(root):
    if sys.flags.optimize: raise ValueError('Optimized Python is unsupported')
    root = Path(root); p = read(root / 'proposal.json')
    assert p['id'] == digest(canonical({k: v for k, v in p.items() if k != 'id'})) and p['proposal_directory'] == str(root.resolve())
    assert p['calls_max'] == 12 and p['stage_caps'] == STAGES and p['character_budget'] == 768 and p['token_budget'] == 384
    for n, sha in p['source_hashes'].items(): assert hashlib.sha256((ROOT / n).read_bytes()).hexdigest() == sha == hashlib.sha256((root / 'frozen-source' / n).read_bytes()).hexdigest()
    for n, sha in p['input_hashes'].items(): assert hashlib.sha256((root / n).read_bytes()).hexdigest() == sha
    for n, sha in p['sealed_archives'].items(): assert hashlib.sha256((ROOT / 'examples' / n).read_bytes()).hexdigest() == sha
    return p


def execute(root, out, approval=None, backend=None, count=None):
    root, out = Path(root), Path(out); p = preflight(root); real = backend is None
    if real:
        if not approval or approval.get('status') != 'approved' or approval.get('proposal_id') != p['id'] or not approval.get('human_source'): raise ValueError('New separately verified direct human approval required')
        assert runtime_check(p) == p['runtime_expected']
        fd = os.open(root / 'execution-intent.json', os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'w') as stream: json.dump({'proposal_id': p['id'], 'human_source': approval['human_source'], 'at': datetime.now(timezone.utc).isoformat()}, stream)
        backend = generation.codex_generate
    out.mkdir(parents=True, exist_ok=False); calls = DirectCalls(out, p, backend); world = read(root / 'world.private.json'); engine = world_engine(read(root / 'domains.json'))
    people = {person['id']: person for person in world['people']}; values = {'full_history': {}, 'temporal': {}}; artifacts = {}; memories = {}; checks = {}; full_gate = None; model = None
    generation.run_bounded = calls.observed_runner
    try:
        for job in read(root / 'jobs.json'):
            if job['stage'] != 'full_history': continue
            pid = job['person_id']; values['full_history'][pid] = answers_checked(calls.call('full_history', job['request']), [c['public'] for c in people[pid]['cases']])
        full_gate = {task: engine.score(world, values['full_history'], task) for task in ('current_choice', 'historical_reconstruction', 'joint')}
        if any(row['correct'] != row['planned'] for row in full_gate.values()): calls.stop('full_source_gate_failed'); raise ValueError('Full source control failed')
        if count is None:
            import llama_cpp
            model = llama_cpp.Llama(model_path=p['tokenizer_path'], vocab_only=True, n_gpu_layers=0, verbose=False)
            count = lambda text: len(model.tokenize(text.encode(), add_bos=False, special=False))
        for job in read(root / 'jobs.json'):
            if job['stage'] != 'shared_extraction': continue
            pid = job['person_id']; artifact = t.bind(calls.call('shared_extraction', job['request']), job['sources']); artifacts[pid] = artifact
            check = source_checks(people[pid], artifact, engine); checks[pid] = check
            if not check['event_span_coverage'] or not all(check['retraction_edges']) or not all(check['current_contexts']): calls.stop('source_to_event_gate_failed', person_id=pid); raise ValueError('Source event gate failed')
            memory = t.render(artifact, 768, count=count, budget_tokens=384); memories[pid] = memory
            if memory['status'] != 'candidate_unvalidated': calls.stop('whole_prompt_budget_failed', person_id=pid); raise ValueError('Whole prompt budget failed')
        for person in world['people']:
            pid = person['id']; public = [c['public'] for c in person['cases']]; request = reader_job('transfer_memory', pid, memories[pid]['text'], public, engine.READER, 12)['request']
            values['temporal'][pid] = answers_checked(calls.call('actual_memory_reader', request), public)
    except Exception as error:
        if not calls.stopped: calls.stop('local_or_format_failure', error_type=type(error).__name__, error=str(error))
    finally:
        generation.run_bounded = ORIGINAL_RUN_BOUNDED
        if model is not None: model.close()
    try: calls.update()
    except Exception: calls.stop('uncertain_checkpoint_state')
    scores = {condition: {task: engine.score(world, predictions, task) for task in ('current_choice', 'historical_reconstruction', 'joint')} for condition, predictions in values.items()}
    current = scores['temporal']['current_choice']; success = not calls.stopped and current['correct'] == 224 and current['matched_domain_contrasts']['correct'] == 6 and current['hard_constraints']['observed_violations'] == 0
    report = {'status': 'stopped' if calls.stopped else 'complete', 'proposal_id': p['id'], 'calls': calls.ledger, 'stage_attempts': dict(calls.counts), 'stop_reason': calls.reason,
        'full_source_gate': full_gate, 'artifacts': artifacts, 'memories': memories, 'source_to_event_checks': checks, 'scores': scores, 'strict_current_target_passed': success,
        'backend_kind': 'actual_service' if real else 'injected_fake_not_model_quality', 'external_model_calls': calls.ledger['execution_records'] if real else 0,
        'paired_statistical_units': 2, 'new_to_experiment_service': True, 'finite_event_grammar_unchanged': True, 'training_independence_verified': False, 'real_person_fidelity_verified': False}
    write_once(out / 'answers.json', values); write_once(out / 'report.json', report); return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--proposal', required=True); parser.add_argument('--run', action='store_true'); parser.add_argument('--approval'); parser.add_argument('--out'); args = parser.parse_args()
    if args.run:
        if not args.approval or not args.out: parser.error('--run requires --approval and --out')
        r = execute(args.proposal, args.out, read(args.approval)); print(json.dumps({'status': r['status'], 'calls': r['calls']['execution_records']}))
    else: print(json.dumps({'proposal_id': preflight(args.proposal)['id'], 'external_model_calls': 0}))
