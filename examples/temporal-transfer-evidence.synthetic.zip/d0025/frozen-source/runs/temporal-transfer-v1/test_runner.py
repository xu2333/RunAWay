import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('transfer_runner', Path(__file__).with_name('runner.py'))
s = importlib.util.module_from_spec(spec); spec.loader.exec_module(s)


def annotation(person, sources, engine):
    units = s.t.spans(sources); by_id = {m[1]: u for u in units if (m := re.match(r'\s*记录([A-Za-z0-9]+)（', u['text']))}
    domains = {d[0]: d for d in engine.DOMAINS}; events = []
    for old in sorted(person['events'], key=lambda e: by_id[e['id']]['start']):
        key = old['key']; kind = {'prefer': 'regular', 'fact': 'regular', 'replace': 'replace', 'except': 'exception', 'hard': 'constraint', 'clear': 'clear', 'revoke': 'retract'}[old['op']]
        events.append({'id': old['id'], 'kind': kind, 'domain': '' if kind == 'retract' else domains[key][1] if key in domains else engine.EXTRA[key][0],
            'action': engine.label(key, old['value']) if 'value' in old else '', 'strength': old.get('strength', 0),
            'when_all': [{'predicate': domains[key][3][int(k[-1])], 'equals': v} for k, v in old.get('when', {}).items()], 'target': old.get('target', ''), 'span_ids': [by_id[old['id']]['id']]})
    used = {sid for e in events for sid in e['span_ids']}
    return {'scope': '虚构的局部选择，仅所列领域。', 'events': events, 'unmodeled': [{'span_id': u['id'], 'reason': 'Source interpretation contract.'} for u in units if u['id'] not in used]}


class TransferTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.base = Path(self.temp.name); self.plan = self.base / 'plan'; self.calls = 0
        runtime = s.read(ROOT / 'runs/temporal-scale-v1/proposed-comparison-reviewed/proposal.json')
        s.prepare(self.plan, runtime, seed=18274521)
        self.world = s.read(self.plan / 'world.private.json'); self.jobs = s.read(self.plan / 'jobs.json'); self.engine = s.world_engine(s.read(self.plan / 'domains.json'))

    def tearDown(self): self.temp.cleanup()

    def fake(self, prompt, model, **kwargs):
        self.calls += 1; self.assertEqual(kwargs['timeout'], 180)
        if kwargs['schema'] == s.t.SCHEMA:
            job = next(j for j in self.jobs if j['stage'] == 'shared_extraction' and j['request']['prompt'] == prompt)
            person = next(p for p in self.world['people'] if p['id'] == job['person_id'])
            payload = json.loads(prompt.split('\nINPUT_JSON:\n', 1)[1]); self.assertEqual(set(payload), {'spans', 'schema'})
            value = annotation(person, job['sources'], self.engine)
        else:
            data = json.loads(prompt.split('\nINPUT_JSON:\n', 1)[1]); person = next(p for p in self.world['people'] if p['cases'][0]['public']['id'] == data['queries'][0]['id'])
            full = data['memory'] == person['history']
            value = {c['public']['id']: c['gold'] if full or c['public']['task'] == 'current_choice' else 'U' for c in person['cases']}
        return json.dumps(value, ensure_ascii=False), {'backend': 'fake_not_quality', 'usage': [{'input_tokens': 1, 'output_tokens': 1}]}

    def run_fake(self, backend=None, count=lambda _: 330, name='out'):
        with patch.object(s.generation, 'codex_generate', side_effect=AssertionError('No real service')):
            return s.execute(self.plan, self.base / name, backend=backend or self.fake, count=count)

    def test_twelve_slots_new_full_controls_and_all_two_pair_denominators(self):
        r = self.run_fake(); self.assertEqual((r['status'], self.calls), ('complete', 12)); self.assertEqual(r['stage_attempts'], s.STAGES)
        self.assertTrue(r['strict_current_target_passed']); self.assertEqual(r['external_model_calls'], 0)
        self.assertEqual(r['scores']['temporal']['current_choice']['correct'], 224)
        self.assertEqual(r['scores']['temporal']['historical_reconstruction']['planned'], 76)
        self.assertEqual(r['scores']['temporal']['joint']['planned'], 300)
        self.assertEqual(r['scores']['temporal']['current_choice']['matched_domain_contrasts']['planned'], 6)
        self.assertEqual(r['paired_statistical_units'], 2); self.assertTrue(r['finite_event_grammar_unchanged'])
        self.assertTrue(all(len(v['current_contexts']) == 27 and all(v['current_contexts']) for v in r['source_to_event_checks'].values()))

    def test_full_control_quality_failure_stops_before_extraction(self):
        def bad_full(prompt, model, **kwargs):
            raw, provenance = self.fake(prompt, model, **kwargs); value = json.loads(raw); value[next(iter(value))] = 'U'; return json.dumps(value), provenance
        r = self.run_fake(bad_full); self.assertEqual((r['status'], self.calls), ('stopped', 4)); self.assertEqual(r['stop_reason']['kind'], 'full_source_gate_failed')
        self.assertEqual(r['scores']['temporal']['joint']['missing'], 300)

    def test_budget_edge_damage_and_unknown_usage_stop_without_extra_calls(self):
        r = self.run_fake(count=lambda _: 385, name='budget'); self.assertEqual(self.calls, 5); self.assertEqual(r['stop_reason']['kind'], 'whole_prompt_budget_failed')
        self.calls = 0
        def edge(prompt, model, **kwargs):
            raw, provenance = self.fake(prompt, model, **kwargs); value = json.loads(raw)
            if kwargs['schema'] == s.t.SCHEMA: next(e for e in value['events'] if e['id'] == 'r18')['target'] = 'r16'
            return json.dumps(value), provenance
        r = self.run_fake(edge, name='edge'); self.assertEqual(self.calls, 5); self.assertEqual(r['stop_reason']['kind'], 'source_to_event_gate_failed')
        self.calls = 0
        def unknown(*args, **kwargs):
            raw, _ = self.fake(*args, **kwargs); return raw, {'backend': 'fake_unknown'}
        r = self.run_fake(unknown, name='unknown'); self.assertEqual((r['status'], self.calls), ('stopped', 1)); self.assertEqual(r['calls']['executions_missing_usage'], 1)

    def test_new_domain_namespace_isolated_and_approval_drift_optimize_blocks(self):
        from runaway import fidelity_stress
        self.assertEqual(fidelity_stress.DOMAINS[0][1], '反馈'); self.assertEqual(self.engine.DOMAINS[0][1], '写作语气')
        with self.assertRaisesRegex(ValueError, 'human approval'): s.execute(self.plan, self.base / 'real')
        self.assertFalse((self.plan / 'execution-intent.json').exists())
        r = subprocess.run([sys.executable, '-O', '-B', str(Path(__file__).with_name('runner.py')), '--proposal', str(self.plan)], capture_output=True, text=True)
        self.assertNotEqual(r.returncode, 0); self.assertIn('Optimized Python is unsupported', r.stderr)
        p = self.plan / 'jobs.json'; p.write_text(p.read_text() + ' ')
        with self.assertRaises(AssertionError): s.preflight(self.plan)


if __name__ == '__main__': unittest.main()
