import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path('frozen-source').resolve()))
from runaway import shared_schema_executor as s
from runaway.card import canonical,digest
from runaway.execution_ledger import checked,collect,summarize
source=s.shared.load_source('source.synthetic.zip');rows={};ids=[];raws={}
for job in source['design']['development_jobs'][:2]:
 request=s.shared.hoist(job['request']);key=digest(canonical(request));ids.append(key)
 assert s.read('calls/'+key+'.request.json')==request
 response=checked(Path('calls/'+key+'.response.json'))
 parsed=s.shared.parse_wire(response['raw'])
 assert parsed==response['answer'] and s.shared.accepts(parsed,request['schema'])
 rows[job['person_id']]=parsed['answers'];raws[key]=response['execution_id']
score=s.score(source,'development',rows,set(rows))
summary=s.read('summary.synthetic.json')
assert s.shared.score_fingerprint(score)==summary['selected_score_fingerprint']
assert all(score[k]['joint']['correct']==score[k]['joint']['planned']==16 for k in s.SCORES)
assert s.complete_gate(score)['passed']
ledger=summarize(collect(Path.cwd()))
assert ledger['execution_records']==ledger['executions_with_usage']==2 and ledger['executions_missing_usage']==0
assert ledger['known_usage']==summary['usage'] and ledger['known_usage']['total_tokens']==14976
assert ids==summary['request_ids'] and len(set(raws.values()))==2
# A changed choice remains wire-valid, but is detected by the frozen score.
import copy
bad=copy.deepcopy(rows);pid=next(iter(bad));key=min(bad[pid]);bad[pid][key]['strict_answer']='A' if bad[pid][key]['strict_answer']!='A' else 'B'
assert not s.complete_gate(s.score(source,'development',bad,set(rows)))['passed']
print(json.dumps(dict(original_responses=2,exact_request_bindings=2,strict=16,status=16,completion=16,outcomes=16,planned=16,contrast=1,usage_total=14976,changed_choice_detected=True,new_model_calls=0,new_token_counts=0)))
