import copy
import importlib.util
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('concise_codec', Path(__file__).with_name('codec.py'))
c = importlib.util.module_from_spec(spec); spec.loader.exec_module(c)


class CodecTests(unittest.TestCase):
    def artifact(self):
        text = '域;硬=🐈：甲或乙；若非条件&"词"，先甲。\n域;硬=🐈：另一条同强度观察先乙。\n未知记号。'
        sources = {'schema_version': 1, 'sources': [{'id': 's', 'episode_id': 'e', 'role': 'user', 'text': text}]}; spans = c.t.spans(sources)
        base = lambda eid, action, i: {'id': eid, 'kind': 'regular', 'domain': '域;硬=🐈', 'action': action, 'strength': 2, 'when_all': [], 'target': '', 'span_ids': [spans[i]['id']]}
        e = base('a', '甲', 0); f = base('b', '乙', 1)
        g = {'id': 'c', 'kind': 'exception', 'domain': '域;硬=🐈', 'action': '甲', 'strength': 0, 'when_all': [{'predicate': '条件&"词"', 'equals': False}], 'target': '', 'span_ids': [spans[0]['id']]}
        return c.t.bind({'scope': '含分隔符的合成范围\n新行\u2028亦保留。', 'events': [e, f, g], 'unmodeled': [{'span_id': spans[2]['id'], 'reason': '未观察选择。'}]}, sources)

    def test_exact_round_trip_and_all_partial_contexts_for_actual_four_people(self):
        for run in ('D-0026-service-v1', 'D-0027-service-v1'):
            for artifact in json.loads((ROOT / 'runs' / run / 'service/report.json').read_text())['artifacts'].values():
                proof = c.prove(artifact); self.assertEqual(proof['partial_contexts'], 38); self.assertTrue(proof['not_model_quality'])
                self.assertEqual(c.decode(c.encode(artifact)['text']), c.policy(artifact))

    def test_quoted_delimiters_unicode_negation_and_conflict_survive(self):
        a = self.artifact(); encoded = c.encode(a)['text']; p = c.decode(encoded); self.assertEqual(p, c.policy(a)); c.prove(a)
        self.assertEqual(c.resolve(p, '域;硬=🐈', {'条件&"词"': False}), {'status': 'chosen', 'action': '甲'})
        self.assertEqual(c.resolve(p, '域;硬=🐈', {'条件&"词"': True}), {'status': 'conflict', 'action': None})
        self.assertEqual(c.resolve(p, '域;硬=🐈', {}), {'status': 'context_unknown', 'action': None})

    def test_whole_budget_never_truncates_or_drops_rules(self):
        a = self.artifact(); full = c.encode(a); self.assertIsNone(c.encode(a, full['characters'] - 1)['text'])
        self.assertIsNone(c.encode(a, count=lambda _: 289, budget_tokens=288)['text'])
        for bad in (True, -1, 1.2):
            with self.assertRaises(ValueError): c.encode(a, count=lambda _: bad, budget_tokens=288)
        with self.assertRaises(ValueError): c.encode(a, budget_tokens=288)

    def test_malformed_envelopes_and_duplicate_conditions_fail_closed(self):
        text = c.encode(self.artifact())['text']
        for bad in (text[:-1], text.replace(';例外', ';其他'), text.replace('未建模:1', '未建模:-1'), text.replace(']=', '&"条件&\\"词\\""]=')):
            with self.assertRaises((ValueError, TypeError, IndexError)): c.decode(bad)
        with self.assertRaises(ValueError): c.decode(text + '\ud800')


if __name__ == '__main__': unittest.main()
