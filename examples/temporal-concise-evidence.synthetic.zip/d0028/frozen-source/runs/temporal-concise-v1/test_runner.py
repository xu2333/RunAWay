import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('concise_runner', Path(__file__).with_name('runner.py'))
s = importlib.util.module_from_spec(spec); spec.loader.exec_module(s)


class ConciseRunnerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.root = Path(self.temp.name); self.plan = self.root / 'plan'; self.calls = 0
        runtime = s.read(ROOT / 'runs/temporal-conflict-transfer-v1/proposed-transfer/proposal.json')
        s.prepare(self.plan, runtime, count=lambda _: 270); self.world = s.read(self.plan / 'world.private.json'); self.jobs = s.read(self.plan / 'jobs.json')

    def tearDown(self): self.temp.cleanup()

    def fake(self, prompt, model, **kwargs):
        self.calls += 1; self.assertEqual(model, 'gpt-6.1-sol'); self.assertEqual(kwargs['timeout'], 180)
        job = next(j for j in self.jobs if j['request']['prompt'] == prompt); person = next(p for p in self.world['people'] if p['id'] == job['persona_id'])
        data = json.loads(prompt.split('\nINPUT_JSON:\n', 1)[1]); self.assertEqual(set(data), {'instruction', 'memory', 'queries', 'source_cutoff'})
        self.assertEqual(s.codec.decode(data['memory']), s.codec.policy(s.read(self.plan / 'artifacts.private.json')[person['id']]))
        return json.dumps({c['public']['id']: c['gold'] if c['public']['task'] == 'current_choice' else 'U' for c in person['cases']}), {'backend': 'fake_not_quality', 'usage': [{'input_tokens': 1, 'output_tokens': 1}]}

    def run_fake(self, backend=None, name='out'):
        with patch.object(s.generation, 'codex_generate', side_effect=AssertionError('No service calls')):
            return s.execute(self.plan, self.root / name, backend=backend or self.fake, count=lambda _: 270)

    def test_four_reader_only_calls_fixed_two_pairs_and_separate_old_controls(self):
        r = self.run_fake(); self.assertEqual(self.calls, 4); self.assertEqual(r['stage_attempts'], {'actual_memory_reader': 4}); self.assertTrue(r['strict_current_target_passed'])
        self.assertEqual(r['external_model_calls'], 0); self.assertEqual(r['paired_statistical_units'], 2)
        self.assertEqual(r['scores']['current_choice']['planned'], 224); self.assertEqual(r['scores']['historical_reconstruction']['planned'], 76); self.assertEqual(r['scores']['joint']['planned'], 300)
        self.assertEqual(r['scores']['current_choice']['matched_domain_contrasts']['planned'], 6)
        self.assertEqual(set(r['separate_old_reference_batches']['separate_old_batches_not_contemporary']), {'D-0026', 'D-0027'})

    def test_unknown_usage_and_format_stop_all_later_keep_missing(self):
        def unknown(*args, **kwargs):
            raw, _ = self.fake(*args, **kwargs); return raw, {'backend': 'fake_unknown'}
        r = self.run_fake(unknown); self.assertEqual((self.calls, r['status']), (1, 'stopped')); self.assertEqual(r['calls']['executions_missing_usage'], 1); self.assertEqual(r['scores']['joint']['missing'], 300)
        self.calls = 0
        def malformed(*args, **kwargs): self.calls += 1; return '{bad', {'usage': [{'input_tokens': 1, 'output_tokens': 1}]}
        r = self.run_fake(malformed, 'bad'); self.assertEqual((self.calls, r['status']), (1, 'stopped'))

    def test_budget_count_drift_unapproved_and_optimize_block_before_service(self):
        with self.assertRaisesRegex(ValueError, 'human approval'): s.execute(self.plan, self.root / 'real')
        self.assertFalse((self.plan / 'execution-intent.json').exists())
        for count in (lambda _: 289, lambda _: 269):
            with self.assertRaises(AssertionError): s.execute(self.plan, self.root / 'budget', backend=self.fake, count=count)
        self.assertEqual(self.calls, 0)
        r = subprocess.run([sys.executable, '-O', '-B', str(Path(__file__).with_name('runner.py')), '--proposal', str(self.plan)], capture_output=True, text=True)
        self.assertNotEqual(r.returncode, 0); self.assertIn('Optimized Python is unsupported', r.stderr)
        path = self.plan / 'jobs.json'; path.write_text(path.read_text() + ' ')
        with self.assertRaises(AssertionError): s.preflight(self.plan)


if __name__ == '__main__': unittest.main()
