"""Separate reader-only test of an experimental shorter current-policy grammar."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from runaway import generation, fidelity_stress as fs
from runaway.card import canonical, digest
from runaway.fidelity_runner import DirectCalls
from runaway.pipeline import write_once
from runaway.taste_executor import answers_checked, runtime_check, ORIGINAL_RUN_BOUNDED
from runaway.taste_plan import reader_job
spec = importlib.util.spec_from_file_location('concise_codec', Path(__file__).with_name('codec.py'))
codec = importlib.util.module_from_spec(spec); spec.loader.exec_module(codec)

STAGES = {'actual_memory_reader': 4}
ARCHIVES = ('pilot-evidence.synthetic.zip', 'comparison-evidence.synthetic.zip', 'stress-service-evidence.synthetic.zip', 'temporal-evidence.synthetic.zip', 'temporal-scale-evidence.synthetic.zip', 'temporal-discrimination-evidence.synthetic.zip', 'temporal-transfer-evidence.synthetic.zip', 'temporal-conflict-repair-evidence.synthetic.zip', 'temporal-conflict-transfer-evidence.synthetic.zip')
read = lambda path: json.loads(Path(path).read_text())


def baseline(world, artifacts, controls):
    predictions = {}; cohorts = {}
    for old in controls:
        pid = old['person_id']; person = next(p for p in world['people'] if p['id'] == pid)
        old_text = codec.t.render(artifacts[pid], 768)['text']
        job = reader_job('temporal_scale', pid, old_text, [c['public'] for c in person['cases']], fs.READER, 12)
        assert job['request'] == old['request'] and job['request_id'] == old['request_id']
        for part in ('response', 'attempt'):
            value = old[part]
            assert value['sha256'] == digest(canonical({k: v for k, v in value.items() if k != 'sha256'})) and value['request_id'] == job['request_id']
        assert old['response']['execution_id'] == old['attempt']['execution_id']
        predictions[pid] = answers_checked(old['response']['answer'], [c['public'] for c in person['cases']])
        cohorts.setdefault(old['decision'], []).append(person)
    assert set(predictions) == {p['id'] for p in world['people']}
    separate = {d: {task: fs.score({'people': people}, predictions, task) for task in ('current_choice', 'historical_reconstruction', 'joint')} for d, people in cohorts.items()}
    assert set(separate) == {'D-0026', 'D-0027'}
    for scores in separate.values():
        assert scores['current_choice']['correct'] == scores['current_choice']['planned'] == 112
        assert scores['historical_reconstruction']['correct'] == 0 and scores['historical_reconstruction']['planned'] == 38
        assert scores['current_choice']['missing'] == scores['historical_reconstruction']['missing'] == 0
    return {'separate_old_batches_not_contemporary': separate, 'no_new_calls_samples_or_costs': True}


def prepare(out, runtime, count=None):
    out = Path(out); out.mkdir(parents=True, exist_ok=False); people = []; artifacts = {}; controls = []
    for decision, name, prefix in [('D-0026', 'temporal-conflict-repair', 'd0026'), ('D-0027', 'temporal-conflict-transfer', 'd0027')]:
        with zipfile.ZipFile(ROOT / ('examples/' + name + '-evidence.synthetic.zip')) as archive:
            world = json.loads(archive.read(prefix + '/world.synthetic.json')); report = json.loads(archive.read(prefix + '/raw-report.synthetic.json'))
            for person in world['people']:
                pid = person['id']; people.append(person); artifacts[pid] = report['artifacts'][pid]
                job = reader_job('temporal_scale', pid, report['memories'][pid]['text'], [c['public'] for c in person['cases']], fs.READER, 12)
                key = job['request_id']; old = {'person_id': pid, 'decision': decision, 'request_id': key}
                for part in ('request', 'response', 'attempt'):
                    data = archive.read(prefix + '/calls/' + key + '.' + part + '.json'); old[part] = json.loads(data); old[part + '_bytes_sha256'] = hashlib.sha256(data).hexdigest()
                controls.append(old)
    world = {'origin': 'consumed_synthetic_development', 'people': people}; old = baseline(world, artifacts, controls); jobs = []; deliveries = {}; proofs = {}; model = None
    try:
        if count is None:
            import llama_cpp
            model = llama_cpp.Llama(model_path=runtime['tokenizer_path'], vocab_only=True, n_gpu_layers=0, verbose=False)
            count = lambda text: len(model.tokenize(text.encode(), add_bos=False, special=False))
        for person in people:
            pid = person['id']; proofs[pid] = codec.prove(artifacts[pid]); delivery = codec.encode(artifacts[pid], count=count, budget_tokens=288); assert delivery['status'] == 'experimental_unvalidated'
            deliveries[pid] = delivery; jobs.append(reader_job('concise_current_policy', pid, delivery['text'], [c['public'] for c in person['cases']], fs.READER, 12))
    finally:
        if model is not None: model.close()
    inputs = {'world.private.json': world, 'artifacts.private.json': artifacts, 'controls.private.json': controls, 'jobs.json': jobs, 'deliveries.private.json': {'memories': deliveries, 'proofs': proofs}}
    for n, value in inputs.items(): write_once(out / n, value)
    code = [str(p.relative_to(ROOT)) for p in sorted((ROOT / 'runaway').glob('*.py'))] + ['runs/temporal-concise-v1/codec.py', 'runs/temporal-concise-v1/test_codec.py', 'runs/temporal-concise-v1/runner.py', 'runs/temporal-concise-v1/test_runner.py']
    body = {'status': 'offline_not_approved_not_executed', 'proposal_directory': str(out.resolve()), 'calls_max': 4, 'stage_caps': STAGES, 'models': {'reader': 'gpt-6.1-sol'},
        **{k: runtime[k] for k in ('python_executable', 'tokenizer', 'tokenizer_path', 'runtime_expected')},
        'timeout_seconds': 180, 'cleanup_waits_seconds': [2, 2], 'character_budget': 768, 'token_budget': 288,
        'selection': 'All4 fixed D26/D27 people,2consumed pairs. No new extraction, resampling or tuning against new model scores. Two initial syntaxes were physically longer and rejected offline; chosen syntax selected by capacity plus exact finite current-policy checks, not LLM quality.',
        'data_scope': 'Only four frozen experimental concise current-memory texts,75public queries/person and necessary READER/SYSTEM/schema/CLI metadata. No source histories/graphs, private parameters/events/gold/context maps, proofs, decoder code, old answers, real/central/workspace data in payload. Credentials only authenticate.',
        'standalone_memory': 'Entire header/grammar explanation, exact scope, unmodeled count and all domains/rules included in measured text. No out-of-band codebook or decoder supplied to model. Does not carry history/provenance/updateable graph; original private artifact retained.',
        'baseline': 'D26 and D27 old memory responses validated and reused OFFLINE as separately measured reference batches, not contemporary controls, new calls/samples/costs. No causal old/new claim; service drift remains. All old requests forbidden and no old balance reused.',
        'reference_baseline': old,
        'gates': 'Before any call verify source/input/9oldarchive/runtime hashes, old request/attempt/response identity and scores, exact codec roundtrip and exhaustive true/false/missing contexts (<=8predicates/domain; never sample), unknown-domain behavior, all4frozen requests, whole768chars/288actualtokens. Any failure, format/transport/timeout, unknown usage or checkpoint state stops entire later batch. No retry/repair/truncation/automatic subset/resampling.',
        'reporting': 'One new reader condition224current+76historical=300joint,112collapsed,6matched contrasts,2consumed paired units. Target224/224current,6/6contrasts,zerohardviolations; preserve all denominators, per-pair and layers, missing distinct fromU. History still reported, no historical capability promised. Quality failure never causes extra calls.',
        'cost_boundary': 'Max4new reader generations, gpt-6.1-sol default CLI reasoning,180sec+2+2cleanup each, same isolation/official existing login/service, no purchases. No aggregate HTTP/token/money/time hard cap.',
        'limits': 'Only a new encoding readout on consumed synthetic policies within fixed event grammar; no fresh holdout, population, real-person, training-independent, cross-provider or causal comparison claim. Program proof is not model fidelity and not whole-trajectory losslessness.',
        'input_hashes': {n: hashlib.sha256((out / n).read_bytes()).hexdigest() for n in inputs}, 'source_hashes': {n: hashlib.sha256((ROOT / n).read_bytes()).hexdigest() for n in code},
        'sealed_archives': {n: hashlib.sha256((ROOT / 'examples' / n).read_bytes()).hexdigest() for n in ARCHIVES},
        'forbidden_request_ids': sorted({Path(n).name.removesuffix('.request.json') for a in ARCHIVES for n in zipfile.ZipFile(ROOT / 'examples' / a).namelist() if n.endswith('.request.json')})}
    assert len({j['request_id'] for j in jobs}) == 4 and not {j['request_id'] for j in jobs} & set(body['forbidden_request_ids'])
    p = {**body, 'id': digest(canonical(body))}; write_once(out / 'proposal.json', p)
    for n in code:
        target = out / 'frozen-source' / n; target.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(ROOT / n, target)
    return p


def preflight(root):
    if sys.flags.optimize: raise ValueError('Optimized Python is unsupported')
    root = Path(root); p = read(root / 'proposal.json')
    assert p['id'] == digest(canonical({k: v for k, v in p.items() if k != 'id'})) and p['proposal_directory'] == str(root.resolve())
    assert p['calls_max'] == 4 and p['stage_caps'] == STAGES and p['token_budget'] == 288 and p['character_budget'] == 768
    for n, sha in p['source_hashes'].items(): assert hashlib.sha256((ROOT / n).read_bytes()).hexdigest() == sha == hashlib.sha256((root / 'frozen-source' / n).read_bytes()).hexdigest()
    for n, sha in p['input_hashes'].items(): assert hashlib.sha256((root / n).read_bytes()).hexdigest() == sha
    for n, sha in p['sealed_archives'].items(): assert hashlib.sha256((ROOT / 'examples' / n).read_bytes()).hexdigest() == sha
    world, artifacts = read(root / 'world.private.json'), read(root / 'artifacts.private.json'); baseline(world, artifacts, read(root / 'controls.private.json'))
    for person, job in zip(world['people'], read(root / 'jobs.json')):
        pid = person['id']; assert codec.prove(artifacts[pid]) == read(root / 'deliveries.private.json')['proofs'][pid]
        memory = codec.encode(artifacts[pid])['text']; assert codec.decode(memory) == codec.policy(artifacts[pid])
        assert reader_job('concise_current_policy', pid, memory, [c['public'] for c in person['cases']], fs.READER, 12) == job
    return p


def execute(root, out, approval=None, backend=None, count=None):
    root, out = Path(root), Path(out); p = preflight(root); real = backend is None
    if real:
        if not approval or approval.get('status') != 'approved' or approval.get('proposal_id') != p['id'] or not approval.get('human_source'): raise ValueError('New separately verified direct human approval required')
        assert runtime_check(p) == p['runtime_expected']
    model = None
    try:
        if count is None:
            import llama_cpp
            model = llama_cpp.Llama(model_path=p['tokenizer_path'], vocab_only=True, n_gpu_layers=0, verbose=False)
            count = lambda text: len(model.tokenize(text.encode(), add_bos=False, special=False))
        memories = read(root / 'deliveries.private.json')['memories']
        for job in read(root / 'jobs.json'):
            pid = job['persona_id']; text = json.loads(job['request']['prompt'].split('\nINPUT_JSON:\n', 1)[1])['memory']; units = count(text)
            assert text == memories[pid]['text'] and len(text) <= 768 and type(units) is int and 0 < units <= 288 and units == memories[pid]['actual_tokens']
    finally:
        if model is not None: model.close()
    if real:
        fd = os.open(root / 'execution-intent.json', os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'w') as stream: json.dump({'proposal_id': p['id'], 'human_source': approval['human_source'], 'at': datetime.now(timezone.utc).isoformat()}, stream)
        backend = generation.codex_generate
    out.mkdir(parents=True, exist_ok=False); calls = DirectCalls(out, p, backend); predictions = {}; world = read(root / 'world.private.json')
    generation.run_bounded = calls.observed_runner
    try:
        for job in read(root / 'jobs.json'):
            public = json.loads(job['request']['prompt'].split('\nINPUT_JSON:\n', 1)[1])['queries']; predictions[job['persona_id']] = answers_checked(calls.call('actual_memory_reader', job['request']), public)
    except Exception as error:
        if not calls.stopped: calls.stop('local_or_format_failure', error_type=type(error).__name__, error=str(error))
    finally: generation.run_bounded = ORIGINAL_RUN_BOUNDED
    try: calls.update()
    except Exception: calls.stop('uncertain_checkpoint_state')
    scores = {task: fs.score(world, predictions, task) for task in ('current_choice', 'historical_reconstruction', 'joint')}; current = scores['current_choice']
    report = {'status': 'stopped' if calls.stopped else 'complete', 'proposal_id': p['id'], 'calls': calls.ledger, 'stage_attempts': dict(calls.counts), 'stop_reason': calls.reason, 'scores': scores,
        'strict_current_target_passed': not calls.stopped and current['correct'] == 224 and current['matched_domain_contrasts']['correct'] == 6 and current['hard_constraints']['observed_violations'] == 0,
        'memories': memories, 'separate_old_reference_batches': baseline(world, read(root / 'artifacts.private.json'), read(root / 'controls.private.json')),
        'backend_kind': 'actual_service' if real else 'injected_fake_not_model_quality', 'external_model_calls': calls.ledger['execution_records'] if real else 0, 'paired_statistical_units': 2, 'new_holdout': False, 'real_person_fidelity_verified': False}
    write_once(out / 'answers.json', predictions); write_once(out / 'report.json', report); return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--proposal', required=True); parser.add_argument('--run', action='store_true'); parser.add_argument('--approval'); parser.add_argument('--out'); args = parser.parse_args()
    if args.run:
        if not args.approval or not args.out: parser.error('--run requires --approval and --out')
        r = execute(args.proposal, args.out, read(args.approval)); print(json.dumps({'status': r['status'], 'calls': r['calls']['execution_records']}))
    else: print(json.dumps({'proposal_id': preflight(args.proposal)['id'], 'external_model_calls': 0}))
