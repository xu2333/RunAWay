import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('conflict_transfer_runner', Path(__file__).with_name('runner.py'))
s = importlib.util.module_from_spec(spec); spec.loader.exec_module(s)


def reference_annotation(person, sources):
    units = s.t.spans(sources); by_record = {m[1]: u for u in units if (m := re.match(r'\s*记录([A-Za-z0-9]+)（', u['text']))}
    domains = {d[0]: d for d in s.fs.DOMAINS}; events = []
    for old in sorted(person['events'], key=lambda e: by_record[e['id']]['start']):
        key = old['key']; kind = {'prefer': 'regular', 'fact': 'regular', 'replace': 'replace', 'except': 'exception', 'hard': 'constraint', 'clear': 'clear', 'revoke': 'retract'}[old['op']]
        events.append({'id': old['id'], 'kind': kind, 'domain': '' if kind == 'retract' else domains[key][1] if key in domains else s.fs.EXTRA[key][0],
            'action': s.fs.label(key, old['value']) if 'value' in old else '', 'strength': old.get('strength', 0),
            'when_all': [{'predicate': domains[key][3][int(k[-1])], 'equals': v} for k, v in old.get('when', {}).items()],
            'target': old.get('target', ''), 'span_ids': [by_record[old['id']]['id']]})
    used = {sid for e in events for sid in e['span_ids']}
    return {'scope': 'Synthetic development reference only.', 'events': events,
            'unmodeled': [{'span_id': u['id'], 'reason': 'Source contract.'} for u in units if u['id'] not in used]}


class ScaleTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.base = Path(self.temp.name); self.plan = self.base / 'plan'
        runtime = json.loads((ROOT / 'runs/timeline-repair-v1/proposed-diagnostic/proposal.json').read_text())
        s.prepare(self.plan, runtime, None)
        self.world = s.read(self.plan / 'world.private.json'); self.jobs = s.read(self.plan / 'jobs.json'); self.calls = 0

    def tearDown(self): self.temp.cleanup()

    def fake(self, prompt, model, **kwargs):
        self.calls += 1; self.assertEqual(kwargs['timeout'], 180)
        if kwargs['schema'] == s.t.SCHEMA:
            job = next(j for j in self.jobs if j['request']['prompt'] == prompt); person = next(p for p in self.world['people'] if p['id'] == job['person_id'])
            value = reference_annotation(person, job['sources'])
            for forbidden in ('"gold"', '"cases"', '"parameters"', '"events":['):
                self.assertNotIn(forbidden, prompt)
        else:
            data = json.loads(prompt.split('\nINPUT_JSON:\n', 1)[1]); pid = next(p['id'] for p in self.world['people'] if p['cases'][0]['public']['id'] == data['queries'][0]['id'])
            person = next(p for p in self.world['people'] if p['id'] == pid)
            value = {c['public']['id']: c['gold'] if c['public']['task'] == 'current_choice' else 'U' for c in person['cases']}
        return json.dumps(value, ensure_ascii=False), {'backend': 'fake_not_quality', 'usage': [{'input_tokens': 1, 'output_tokens': 1}]}

    def run_fake(self, backend=None, count=lambda text: 330, name='out'):
        with patch.object(s.generation, 'codex_generate', side_effect=AssertionError('No new service calls')):
            return s.execute(self.plan, self.base / name, backend=backend or self.fake, count=count)

    def test_four_new_calls_prior_controls_only_reused_and_all_denominators_retained(self):
        report = self.run_fake(); self.assertEqual((report['status'], self.calls), ('complete', 4))
        self.assertEqual(report['external_model_calls'], 0)
        self.assertEqual(report['stage_attempts'], s.STAGES)
        self.assertEqual(report['scores']['current_choice']['planned'], 112)
        self.assertEqual(report['scores']['historical_reconstruction']['planned'], 38)
        self.assertEqual(report['scores']['joint']['planned'], 150)
        self.assertEqual(report['scores']['current_choice']['correct'], 112)
        self.assertEqual(report['scores']['current_choice']['matched_domain_contrasts']['planned'], 3)
        self.assertEqual(report['prior_controls_reused_offline_not_new']['joint']['correct'], 150)
        self.assertTrue(all(len(c['current_contexts']) == 27 and all(c['current_contexts']) and len(c['current_statuses']) == 27 and all(c['current_statuses']) for c in report['source_to_event_checks'].values()))

    def test_budget_or_graph_or_unknown_usage_stops_whole_remaining_batch(self):
        report = self.run_fake(count=lambda text: 385, name='budget')
        self.assertEqual((report['status'], self.calls), ('stopped', 1)); self.assertEqual(report['scores']['joint']['missing'], 150)
        self.calls = 0
        def bad_graph(*args, **kwargs):
            raw, p = self.fake(*args, **kwargs); value = json.loads(raw)
            if kwargs['schema'] == s.t.SCHEMA:
                by_id = {e['id']: e for e in value['events']}; e = next(e for e in value['events'] if e['kind'] == 'retract' and by_id[e['target']]['kind'] == 'retract'); e['target'] = by_id[e['target']]['target']
            return json.dumps(value), p
        report = self.run_fake(bad_graph, name='graph'); self.assertEqual((report['status'], self.calls), ('stopped', 1))
        self.calls = 0
        def unknown(*args, **kwargs):
            raw, _ = self.fake(*args, **kwargs); return raw, {'backend': 'fake_unknown'}
        report = self.run_fake(unknown, name='unknown'); self.assertEqual((report['status'], self.calls), ('stopped', 1)); self.assertEqual(report['calls']['executions_missing_usage'], 1)

    def test_lost_conflict_can_pass_actions_but_fails_explicit_state_and_coverage(self):
        person = self.world['people'][0]; sources = self.jobs[0]['sources']; value = reference_annotation(person, sources)
        ids = {e['span_ids'][0] for e in value['events'] if e['id'] in ('rc1', 'rc2')}
        value['events'] = [e for e in value['events'] if e['id'] not in ('rc1', 'rc2')]
        value['unmodeled'] += [{'span_id': sid, 'reason': 'Conflicting observations wrongly skipped.'} for sid in ids]
        check = s.source_checks(person, s.t.bind(value, sources))
        self.assertTrue(all(check['current_contexts']))
        self.assertFalse(check['event_span_coverage']); self.assertFalse(all(check['current_statuses']))

    def test_unapproved_and_prior_control_drift_block_before_backend(self):
        with self.assertRaisesRegex(ValueError, 'human approval'): s.execute(self.plan, self.base / 'real')
        self.assertFalse((self.plan / 'execution-intent.json').exists())
        optimized = subprocess.run([sys.executable, '-O', '-B', str(Path(__file__).with_name('runner.py')), '--proposal', str(self.plan)], text=True, capture_output=True)
        self.assertNotEqual(optimized.returncode, 0)
        self.assertIn('Optimized Python is unsupported', optimized.stderr)
        path = self.plan / 'prior-controls.private.json'; path.write_text(path.read_text() + ' ')
        with self.assertRaises(AssertionError): s.preflight(self.plan)


if __name__ == '__main__': unittest.main()
