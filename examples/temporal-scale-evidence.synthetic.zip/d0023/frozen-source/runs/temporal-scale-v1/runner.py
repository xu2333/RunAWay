"""Four NEW calls for a consumed multi-domain development pair. Never auto-runs."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from runaway import temporal as t, fidelity_stress as fs, generation
from runaway.card import canonical, digest
from runaway.execution_ledger import checked
from runaway.fidelity_runner import DirectCalls
from runaway.pipeline import write_once
from runaway.selfplay import SYSTEM
from runaway.taste_executor import ORIGINAL_RUN_BOUNDED, answers_checked, runtime_check
from runaway.taste_plan import reader_job

STAGES = {'shared_extraction': 2, 'actual_memory_reader': 2}
ARCHIVES = ('pilot-evidence.synthetic.zip', 'comparison-evidence.synthetic.zip', 'stress-service-evidence.synthetic.zip', 'temporal-evidence.synthetic.zip')
read = lambda p: json.loads(Path(p).read_text())


def old_controls(world, controls):
    predictions = {}
    for person, old in zip(world['people'], controls):
        public = [c['public'] for c in person['cases']]
        job = reader_job('full_history', person['id'], person['history'], public, fs.READER, 12)
        assert job['request'] == old['request'] and job['request_id'] == old['request_id']
        for key in ('response', 'attempt'):
            assert old[key]['sha256'] == digest(canonical({k: v for k, v in old[key].items() if k != 'sha256'}))
            assert old[key]['request_id'] == old['request_id']
        assert old['response']['execution_id'] == old['attempt']['execution_id']
        predictions[person['id']] = answers_checked(old['response']['answer'], public)
    result = {task: fs.score(world, predictions, task) for task in ('current_choice', 'historical_reconstruction', 'joint')}
    assert all(v['correct'] == v['planned'] for v in result.values())
    return result


def prepare(out, runtime, runtime_expected):
    out = Path(out); out.mkdir(parents=True, exist_ok=False)
    with zipfile.ZipFile(ROOT / 'examples/stress-service-evidence.synthetic.zip') as archive:
        original = json.loads(archive.read('d0018/fixtures.synthetic.json'))
        world = {'origin': 'consumed_synthetic_development', 'people': [{k: p[k] for k in ('id', 'pair_id', 'twin', 'target_axes', 'history', 'events', 'cases')} for p in original['people'][:2]]}
        controls = []
        for person in world['people']:
            job = reader_job('full_history', person['id'], person['history'], [c['public'] for c in person['cases']], fs.READER, 12)
            key = job['request_id']; control = {'request_id': key}
            for part in ('request', 'response', 'attempt'):
                data = archive.read(f'd0018/calls/{key}.{part}.json')
                control[part] = json.loads(data); control[part + '_bytes_sha256'] = hashlib.sha256(data).hexdigest()
            controls.append(control)
    prior = old_controls(world, controls)
    jobs = []
    for person in world['people']:
        sources = {'schema_version': 1, 'sources': [{'id': 'history', 'episode_id': 'consumed-scale-development', 'role': 'user', 'text': person['history']}]}
        request = {'prompt': t.make_request(sources), 'schema': t.SCHEMA, 'model': 'gpt-6-luna', 'system': SYSTEM}
        jobs.append({'person_id': person['id'], 'sources': sources, 'request': request})
    write_once(out / 'world.private.json', world); write_once(out / 'jobs.json', jobs); write_once(out / 'prior-controls.private.json', controls)
    code = [str(p.relative_to(ROOT)) for p in sorted((ROOT / 'runaway').glob('*.py'))]
    code += ['runs/temporal-scale-v1/runner.py', 'runs/temporal-scale-v1/test_runner.py', 'web/dist/temporal-protocol.json', 'web/dist/temporal-core.mjs']
    body = {'status': 'offline_not_approved_not_executed', 'proposal_directory': str(out.resolve()),
        'calls_max': 4, 'stage_caps': STAGES, 'models': {'generator': 'gpt-6-luna', 'reader': 'gpt-6.1-sol'},
        'python_executable': runtime['python_executable'], 'tokenizer': runtime['tokenizer'], 'tokenizer_path': runtime['tokenizer_path'], 'runtime_expected': runtime_expected,
        'character_budget': 768, 'token_budget': 384, 'timeout_seconds': 180, 'cleanup_waits_seconds': [2, 2],
        'history_characters': sum(len(p['history']) for p in world['people']),
        'selection': 'Fixed first D18 paired cluster, two already-consumed synthetic people, all six main domains plus cleared/conflicting preferences. No model-based sample selection. One statistical unit.',
        'data_scope': 'Only full synthetic histories, actual derived event graphs/current memories, public75 queries/person and required system/schema/CLI metadata. No real data, workspace/central messages, private event metadata/parameters/gold/context mappings or credentials in payload. Private scoring data never enters extraction.',
        'prior_controls': 'Two completed D18 full-source responses are validated and reused OFFLINE, not re-executed, not new calls or new samples. They are not contemporary controls. Their costs remain in D18, not charged again. No old unused budget is reused.',
        'prior_control_scores': prior,
        'gates': 'Before any new call verify original source-control request/attempt/response identities and perfect prior scores. Each actual extraction must validate every source span and graph, cover every event-bearing source line, preserve every retraction edge and resolve all27 current non-instruction source contexts/person. Budget768 chars/384 actual tokens. Failure stops all later calls; no repair/truncation/resampling. Format, transport, timeout, unknown usage/state or frozen drift also stops.',
        'reporting': 'Each reader condition retains112 current +38 historical =150 joint,56 collapsed scenarios and3 matched domain contrasts. Missing differs from U. Current-only prompt still loses historical reconstruction. One consumed pair, no fresh holdout, causal old/new, real-person or cross-provider claim.',
        'cost_boundary': 'At most4 new experiment generations:2 event extractions +2 memory readers. Every call180s plus2+2cleanup, zero retries. Existing official Codex login, default reasoning, unchanged isolation observer, no purchases. No aggregate HTTP/token/money/time hard ceiling.',
        'input_hashes': {n: hashlib.sha256((out / n).read_bytes()).hexdigest() for n in ('world.private.json', 'jobs.json', 'prior-controls.private.json')},
        'source_hashes': {n: hashlib.sha256((ROOT / n).read_bytes()).hexdigest() for n in code},
        'sealed_archives': {n: hashlib.sha256((ROOT / 'examples' / n).read_bytes()).hexdigest() for n in ARCHIVES},
        'forbidden_request_ids': sorted({Path(n).name.removesuffix('.request.json') for a in ARCHIVES for n in zipfile.ZipFile(ROOT / 'examples' / a).namelist() if n.endswith('.request.json')})}
    proposal = {**body, 'id': digest(canonical(body))}; write_once(out / 'proposal.json', proposal)
    for name in code:
        target = out / 'frozen-source' / name; target.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(ROOT / name, target)
    return proposal


def preflight(root):
    if sys.flags.optimize:
        raise ValueError('Optimized Python is unsupported; frozen assertion checks must remain enabled')
    root = Path(root); p = read(root / 'proposal.json')
    assert p['id'] == digest(canonical({k: v for k, v in p.items() if k != 'id'})) and p['proposal_directory'] == str(root.resolve())
    assert p['calls_max'] == 4 and p['stage_caps'] == STAGES and p['token_budget'] == 384 and p['character_budget'] == 768
    for name, sha in p['source_hashes'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == sha
        assert hashlib.sha256((root / 'frozen-source' / name).read_bytes()).hexdigest() == sha
    for name, sha in p['input_hashes'].items():
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == sha
    for name, sha in p['sealed_archives'].items():
        assert hashlib.sha256((ROOT / 'examples' / name).read_bytes()).hexdigest() == sha
    old_controls(read(root / 'world.private.json'), read(root / 'prior-controls.private.json'))
    return p


def source_checks(person, artifact):
    spans = {m[1]: s['id'] for s in artifact['source_spans'] if (m := re.match(r'\s*记录([A-Za-z0-9]+)（', s['text']))}
    events = artifact['extraction']['events']; used = {sid for e in events for sid in e['span_ids']}; by_id = {e['id']: e for e in events}
    edges = []
    for old in person['events']:
        if old['op'] != 'revoke': continue
        found = [e for e in events if e['kind'] == 'retract' and spans[old['id']] in e['span_ids']]
        edges.append(len(found) == 1 and spans[old['target']] in by_id[found[0]['target']]['span_ids'])
    domains = {d[0]: d for d in fs.DOMAINS}; contexts = []
    for case in person['cases']:
        if case['public']['task'] != 'current_choice' or case['order'] != 0 or case['instruction']: continue
        key = case['key']; domain = domains[key][1] if key in domains else fs.EXTRA[key][0]
        context = {domains[key][3][int(k[-1])]: v for k, v in case['context'].items()} if key in domains else {}
        expected = None if case['action'] == 'U' else fs.label(key, case['action'])
        contexts.append(t.resolve(artifact, domain, context)['action'] == expected)
    return {'event_span_coverage': set(spans.values()) <= used, 'retraction_edges': edges, 'current_contexts': contexts}


def execute(root, out, approval=None, backend=None, count=None):
    root, out = Path(root), Path(out); p = preflight(root); real = backend is None
    if real:
        if not approval or approval.get('status') != 'approved' or approval.get('proposal_id') != p['id'] or not approval.get('human_source'):
            raise ValueError('Separate direct human approval for this exact FOUR-call batch required')
        assert p['runtime_expected'] and runtime_check(p) == p['runtime_expected']
        fd = os.open(root / 'execution-intent.json', os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'w') as stream: json.dump({'proposal_id': p['id'], 'human_source': approval['human_source'], 'at': datetime.now(timezone.utc).isoformat()}, stream)
        backend = generation.codex_generate
    out.mkdir(parents=True, exist_ok=False); world = read(root / 'world.private.json'); jobs = read(root / 'jobs.json')
    calls = DirectCalls(out, p, backend); predictions = {}; artifacts = {}; memories = {}; checks = {}; tokenizer = None
    generation.run_bounded = calls.observed_runner
    try:
        if count is None:
            import llama_cpp
            tokenizer = llama_cpp.Llama(model_path=p['tokenizer_path'], vocab_only=True, n_gpu_layers=0, verbose=False)
            count = lambda text: len(tokenizer.tokenize(text.encode(), add_bos=False, special=False))
        for person, job in zip(world['people'], jobs):
            pid = person['id']; artifact = t.bind(calls.call('shared_extraction', job['request']), job['sources']); artifacts[pid] = artifact
            check = source_checks(person, artifact); checks[pid] = check
            if not check['event_span_coverage'] or not all(check['retraction_edges']) or not all(check['current_contexts']):
                calls.stop('source_to_event_gate_failed', person_id=pid); raise ValueError('Source-to-event checks failed')
            memory = t.render(artifact, 768, count=count, budget_tokens=384); memories[pid] = memory
            if memory['status'] != 'candidate_unvalidated':
                calls.stop('whole_prompt_budget_failed', person_id=pid); raise ValueError('Whole prompt budget failed')
        for person in world['people']:
            pid = person['id']; public = [c['public'] for c in person['cases']]
            request = reader_job('temporal_scale', pid, memories[pid]['text'], public, fs.READER, 12)['request']
            predictions[pid] = answers_checked(calls.call('actual_memory_reader', request), public)
    except Exception as error:
        if not calls.stopped: calls.stop('local_or_format_failure', error_type=type(error).__name__, error=str(error))
    finally:
        generation.run_bounded = ORIGINAL_RUN_BOUNDED
        if tokenizer is not None: tokenizer.close()
    try: calls.update()
    except Exception: calls.stop('uncertain_checkpoint_state')
    report = {'status': 'stopped' if calls.stopped else 'complete', 'proposal_id': p['id'], 'calls': calls.ledger, 'stage_attempts': dict(calls.counts), 'stop_reason': calls.reason,
        'prior_controls_reused_offline_not_new': old_controls(world, read(root / 'prior-controls.private.json')),
        'source_to_event_checks': checks, 'artifacts': artifacts, 'memories': memories,
        'scores': {task: fs.score(world, predictions, task) for task in ('current_choice', 'historical_reconstruction', 'joint')},
        'external_model_calls': calls.ledger['execution_records'] if real else 0, 'backend_kind': 'actual_service' if real else 'injected_fake_not_quality',
        'paired_statistical_units': 1, 'new_holdout': False, 'real_person_fidelity_verified': False}
    write_once(out / 'answers.json', predictions); write_once(out / 'report.json', report); return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--proposal', required=True); parser.add_argument('--run', action='store_true'); parser.add_argument('--approval'); parser.add_argument('--out'); args = parser.parse_args()
    if args.run:
        if not args.approval or not args.out: parser.error('--run needs --approval and --out')
        r = execute(args.proposal, args.out, read(args.approval)); print(json.dumps({'status': r['status'], 'calls': r['calls']['execution_records']}))
    else: print(json.dumps({'proposal_id': preflight(args.proposal)['id'], 'external_model_calls': 0}))
