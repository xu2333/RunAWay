"""Frozen two-reader preparation. Default mode is offline; no implicit service entry."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from runaway import generation, fidelity_stress as fs, temporal_stress as stress, temporal_concise as codec
from runaway.card import canonical, digest
from runaway.fidelity_runner import DirectCalls
from runaway.pipeline import write_once
from runaway.taste_executor import answers_checked, runtime_check, ORIGINAL_RUN_BOUNDED, atomic
from runaway.taste_plan import reader_job

STAGES = {'actual_memory_reader': 2}
INPUTS = ('jobs.json', 'gold.private.json', 'design.original.json', 'world.private.json', 'deliveries.private.json', 'executor-acceptance.json')
MATRIX = {'people': 2, 'paired_units': 1, 'queries_per_person': 18, 'current': 36, 'partial_context': 20,
          'complete_context': 16, 'collapsed_current': 18, 'matched_contrasts': 1, 'active_hard_queries': 4, 'historical_planned': 0}
DESIGN = 'runs/temporal-partial-context-v1/next-reader-design'
PUBLIC_WORLD = 'examples/temporal-partial-context/world.synthetic.json'
ARCHIVES = ('pilot-evidence.synthetic.zip', 'comparison-evidence.synthetic.zip', 'stress-service-evidence.synthetic.zip',
    'temporal-evidence.synthetic.zip', 'temporal-scale-evidence.synthetic.zip', 'temporal-discrimination-evidence.synthetic.zip',
    'temporal-transfer-evidence.synthetic.zip', 'temporal-conflict-repair-evidence.synthetic.zip',
    'temporal-conflict-transfer-evidence.synthetic.zip', 'temporal-concise-evidence.synthetic.zip')
read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def require(ok, message):
    if not ok: raise ValueError(message)


def sources():
    return [str(p.relative_to(ROOT)) for p in sorted((ROOT / 'runaway').glob('*.py'))] + [
        'runs/temporal-partial-reader-v1/runner.py', 'runs/temporal-partial-reader-v1/test_runner.py']


def old_request_ids():
    ids = set()
    for name in ARCHIVES:
        with zipfile.ZipFile(ROOT / 'examples' / name) as z:
            ids.update(Path(n).name.removesuffix('.request.json') for n in z.namelist() if n.endswith('.request.json'))
    return sorted(ids)


def score(world, predictions):
    current = fs.score(world, predictions, 'current_choice')
    slices = {name: {'correct': 0, 'planned': 0, 'missing': 0, 'unknown_answers': 0} for name in ('partial_context', 'complete_context')}
    for p in world['people']:
        for c in p['cases']:
            if c['public']['task'] != 'current_choice': continue
            value = predictions.get(p['id'], {}).get(c['public']['id'])
            row = slices['complete_context' if len(c['context']) == 2 else 'partial_context']
            row['planned'] += 1; row['correct'] += value == c['gold']; row['missing'] += value is None; row['unknown_answers'] += value == 'U'
    return {'current_choice': current, 'context_slices': slices,
        'historical_reconstruction': {'status': 'not_planned_not_measured', 'planned': 0, 'correct': None},
        'state_preservation': {'status': 'not_measured_by_answer_only_schema', 'correct': None}}


def semantics(world, jobs, gold, deliveries):
    require(world == stress.build_world() == read(ROOT / PUBLIC_WORLD), 'Fixed published world changed')
    require(len(jobs) == 2 and [j['persona_id'] for j in jobs] == ['partial-0', 'partial-1'], 'Fixed pair/order changed')
    truths = {}; proofs = {}
    for person, job in zip(world['people'], jobs):
        pid = person['id']; cases = [c for c in person['cases'] if c['public']['task'] == 'current_choice']
        require(gold[pid] == cases and len(cases) == 18, 'Fixed18queries/gold changed')
        text = codec.encode(person['artifact'], budget_chars=768)['text']
        require(deliveries['memories'][pid]['text'] == text, 'Encoding changed')
        require(job == reader_job('partial_context_current', pid, text, [c['public'] for c in cases], fs.READER, 12), 'Original request changed')
        decoded = codec.decode(text); truths[pid] = {}
        for c in cases:
            context = {name: c['context'][key] for key, name in [('c0', stress.P), ('c1', stress.Q)] if key in c['context']}
            result = codec.resolve(decoded, stress.DOMAIN, context)
            action = str(stress.ACTIONS.index(result['action'])) if result['status'] == 'chosen' else 'U'
            require((action, result['status']) == (c['action'], c['expected_status']), 'Independent authored truth mismatch')
            truths[pid][c['public']['id']] = c['gold']
        proofs[pid] = codec.prove(person['artifact'])
    require(deliveries['proofs'] == proofs, 'Current-policy proof changed')
    baseline = score(world, truths)
    require(baseline['current_choice']['correct'] == 36 and baseline['context_slices']['partial_context']['planned'] == 20
            and baseline['context_slices']['complete_context']['planned'] == 16, 'Fixed denominators changed')
    require(baseline['current_choice']['matched_domain_contrasts']['correct'] == 1
            and baseline['current_choice']['hard_constraints']['active_hard_queries'] == 4, 'Contrast/hard denominator changed')
    return baseline


def counted_deliveries(world, jobs, count):
    memories = {}; proofs = {}
    for person in world['people']:
        pid = person['id']; item = codec.encode(person['artifact'], 768, count, 288)
        require(item['text'] is not None and item['status'] == 'experimental_unvalidated', 'Whole-memory budget blocked')
        require(type(item['actual_tokens']) is int and 0 < item['actual_tokens'] <= 288, 'Invalid actual token count')
        memories[pid] = item; proofs[pid] = codec.prove(person['artifact'])
    requests = {}
    for job in jobs:
        text = canonical(job['request']); units = count(text)
        require(type(units) is int and units > 0, 'Invalid request-envelope tokenizer count')
        requests[job['request_id']] = {'characters':len(text),'utf8_bytes':len(text.encode()),
            'actual_local_vocabulary_tokens':units,'not_service_token_usage_or_price_cap':True}
    return {'memories': memories, 'proofs': proofs, 'request_envelope_lengths':requests}


def with_counter(config, operation):
    import llama_cpp
    model = llama_cpp.Llama(model_path=config['tokenizer_path'], vocab_only=True, n_gpu_layers=0, verbose=False)
    try: return operation(lambda text: len(model.tokenize(text.encode(), add_bos=False, special=False)))
    finally: model.close()


def prepare(out, runtime, acceptance=None, count=None):
    root = Path(out); root.mkdir(parents=True, exist_ok=False)
    original = ROOT / DESIGN; world = read(ROOT / PUBLIC_WORLD); jobs = read(original / 'jobs.json'); gold = read(original / 'gold.private.json')
    deliveries = counted_deliveries(world, jobs, count) if count else with_counter(runtime, lambda counter: counted_deliveries(world, jobs, counter))
    baseline = semantics(world, jobs, gold, deliveries); hashes = {n: sha(ROOT / n) for n in sources()}
    evidence = acceptance or {'status': 'test_fixture_only_not_service_acceptance', 'all_checks_passed': False, 'external_model_calls': 0, 'source_hashes': hashes}
    require(evidence['source_hashes'] == hashes and evidence['external_model_calls'] == 0, 'Offline acceptance/source mismatch')
    for source, target in [('jobs.json', 'jobs.json'), ('gold.private.json', 'gold.private.json'), ('design.json', 'design.original.json')]:
        shutil.copyfile(original / source, root / target)
    write_once(root / 'world.private.json', world); write_once(root / 'deliveries.private.json', deliveries); write_once(root / 'executor-acceptance.json', evidence)
    body = {'status': 'offline_ready_for_separate_review' if evidence['all_checks_passed'] else 'offline_unaccepted_test_fixture',
        'proposal_directory': str(root.resolve()), 'calls_max': 2, 'stage_caps': STAGES, 'models': {'reader': 'gpt-6.1-sol'},
        **{k: runtime[k] for k in ('python_executable', 'tokenizer', 'tokenizer_path', 'runtime_expected')},
        'timeout_seconds': 180, 'cleanup_waits_seconds': [2,2], 'character_budget': 768, 'token_budget': 288,
        'reasoning': 'CLI default, no reasoning-effort override', 'original_design_id': read(original / 'design.json')['id'],
        'input_hashes': {n: sha(root / n) for n in INPUTS}, 'source_hashes': hashes,
        'old_archives': {n: sha(ROOT / 'examples' / n) for n in ARCHIVES}, 'forbidden_request_ids': old_request_ids(),
        'matrix': MATRIX,
        'selection': 'Exact already-public authored mirrored pair and original18queries/person. Copy original jobs byte-for-byte, no extraction, new people, query rewrite, encoding adjustment, repair or resampling.',
        'data_scope': 'Only two complete frozen synthetic current-memory texts,total374characters,18public queries/person and necessary READER/SYSTEM/schema/CLI metadata to existing official logged-in OpenAI Codex service. No source histories/graphs, gold/status table/context scoring maps, proofs, code, old answers, real-user or chat/workspace contents; credentials only authenticate.',
        'isolation': 'Reuse DirectCalls and unchanged FrozenCalls.observed_runner/generation.run_bounded: empty temporary workspace with onlysystem.txt/schema.json, read-only sandbox, ephemeral/ignore-user-config/skip-git-repo-check, no project docs/memories/MCP/web/tools/skills/plugins/hooks/apps/subagents, no reasoning override.',
        'gates': 'Before any service entry verify all source/input/oldarchive hashes, exact original request bytes/IDs, runtime, authored-gold/current-policy equivalence and proof, whole768chars/288actualtokens with exact frozen counts. Single exclusive intent, output must be new and outside proposal; copied proposal, existing intent/output or old request blocks. Format/transport/timeout/unknown usage/checkpoint/runtime/hash/budget failure stops all later calls. No retry/repair/truncation/subset/resampling or old budget reuse.',
        'reporting': 'Fixed36current,20partial+16complete,18collapsed,1matched contrast,4active hard queries. Per-person, both slices, missing/U/invalid and hard errors/violations reported; historical planned0 is unmeasured, no state-preservation inference from answer-only schema. Strict target36/36+1/1contrast+zeroactualviolations, quality below target reported without extra calls.',
        'cost_boundary': 'At most2new reader generations,180seconds+2+2cleanup each, existing account only/no purchases. Not a hard aggregate HTTP/token/money/time cap. Separate old service costs and host development usage; no service invoice inference.',
        'limitations': 'One consumed published single-domain authored template/pair; no fresh holdout, population, real-person, cross-provider, historical or causal claim. Query wording already explicitly says missing is not false, so this is an instructed reader diagnostic, not unprompted generalization. Program controls/proofs are not model-quality evidence.',
        'baseline_program_not_model_quality': baseline}
    proposal = {**body, 'id': digest(canonical(body))}; write_once(root / 'proposal.json', proposal)
    for name in hashes:
        target = root / 'frozen-source' / name; target.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(ROOT / name, target)
    return proposal


def preflight(root):
    require(not sys.flags.optimize, 'Optimized Python is unsupported')
    root = Path(root).resolve(); p = read(root / 'proposal.json')
    require(p['id'] == digest(canonical({k:v for k,v in p.items() if k!='id'})), 'Proposal changed')
    require(p['proposal_directory'] == str(root), 'Copied/moved proposal cannot bypass single use')
    require(p['calls_max'] == 2 and p['stage_caps'] == STAGES and p['models'] == {'reader':'gpt-6.1-sol'}
            and p['timeout_seconds'] == 180 and p['cleanup_waits_seconds'] == [2,2] and p['character_budget'] == 768 and p['token_budget'] == 288, 'Execution policy changed')
    require(set(p['source_hashes']) == set(sources()), 'Frozen source set changed')
    require(set(p['input_hashes']) == set(INPUTS) and p['matrix'] == MATRIX, 'Input/matrix set changed')
    for n, expected in p['source_hashes'].items():
        require(sha(ROOT / n) == expected == sha(root / 'frozen-source' / n), 'Frozen source changed: '+n)
    for n, expected in p['input_hashes'].items(): require(sha(root / n) == expected, 'Frozen input changed: '+n)
    require(set(p['old_archives']) == set(ARCHIVES), 'Old archive set changed')
    for n, expected in p['old_archives'].items(): require(sha(ROOT / 'examples' / n) == expected, 'Old archive changed: '+n)
    require(p['forbidden_request_ids'] == old_request_ids(), 'Old request prohibition changed')
    original = ROOT / DESIGN; d = read(root / 'design.original.json')
    require(d['id'] == digest(canonical({k:v for k,v in d.items() if k!='id'})) == p['original_design_id'], 'Original design changed')
    for name in ('jobs.json', 'gold.private.json'):
        require(sha(root / name) == sha(original / name) == d['input_hashes'][name], 'Original fixed input changed')
    require((root / 'design.original.json').read_bytes() == (original / 'design.json').read_bytes(), 'Original design bytes changed')
    world, jobs, gold = read(root / 'world.private.json'), read(root / 'jobs.json'), read(root / 'gold.private.json')
    baseline = semantics(world, jobs, gold, read(root / 'deliveries.private.json'))
    require(baseline == p['baseline_program_not_model_quality'], 'Program baseline changed')
    require(len({j['request_id'] for j in jobs}) == 2 and not {j['request_id'] for j in jobs}.intersection(p['forbidden_request_ids']), 'Duplicate or old request')
    evidence = read(root / 'executor-acceptance.json')
    require(evidence['source_hashes'] == p['source_hashes'] and evidence['external_model_calls'] == 0, 'Acceptance/source changed')
    return p


def claim(root, out, p, approval, real):
    require(not out.exists(), 'Existing output cannot be resumed/retried')
    require(not out.is_relative_to(root) and not root.is_relative_to(out), 'Output must be outside proposal tree')
    fd = os.open(root / 'execution-intent.json', os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w') as stream:
        json.dump({'proposal_id': p['id'], 'output':str(out), 'human_source':approval.get('human_source') if approval else None,
            'backend_kind':'actual_service' if real else 'injected_fake_not_model_quality','at':datetime.now(timezone.utc).isoformat()},stream)


def execute(root, out, approval=None, backend=None, count=None):
    root, out = Path(root).resolve(), Path(out).resolve(); p = preflight(root); real = backend is None
    if real:
        require(approval and approval.get('status') == 'approved' and approval.get('proposal_id') == p['id'] and approval.get('human_source'), 'Separate independently verified direct human approval required')
        evidence = read(root / 'executor-acceptance.json')
        require(evidence['all_checks_passed'] is True and evidence.get('status') == 'offline_acceptance_passed', 'Real execution requires bound offline acceptance')
        require(runtime_check(p) == p['runtime_expected'] == evidence['runtime_local_only'], 'Frozen runtime drifted')
    def recount(counter):
        actual = counted_deliveries(read(root / 'world.private.json'), read(root / 'jobs.json'), counter)
        require(actual == read(root / 'deliveries.private.json'), 'Frozen actual token count drifted')
    recount(count) if count else with_counter(p,recount)
    claim(root,out,p,approval,real)
    if real: backend = generation.codex_generate
    out.mkdir(parents=True,exist_ok=False); calls = DirectCalls(out,p,backend); predictions = {}; world = read(root / 'world.private.json')
    generation.run_bounded = calls.observed_runner
    try:
        for job in read(root / 'jobs.json'):
            public = json.loads(job['request']['prompt'].split('\nINPUT_JSON:\n',1)[1])['queries']
            predictions[job['persona_id']] = answers_checked(calls.call('actual_memory_reader',job['request']),public)
            atomic(out / 'answers.json',predictions)
    except Exception as error:
        if not calls.stopped: calls.stop('local_or_format_failure',error_type=type(error).__name__,error=str(error))
    finally: generation.run_bounded = ORIGINAL_RUN_BOUNDED
    try: calls.update()
    except Exception: calls.stop('uncertain_checkpoint_state')
    scores = score(world,predictions); c = scores['current_choice']
    passed = not calls.stopped and c['correct'] == 36 and c['matched_domain_contrasts']['correct'] == 1 and c['hard_constraints']['observed_violations'] == 0
    report = {'status':'stopped' if calls.stopped else 'complete','proposal_id':p['id'],'backend_kind':'actual_service' if real else 'injected_fake_not_model_quality',
        'strict_target_passed':passed,'scores':scores,'calls':calls.ledger,'stage_attempts':dict(calls.counts),'stop_reason':calls.reason,
        'external_model_calls':calls.ledger.get('execution_records') if real else 0,'paired_statistical_units':1,'new_holdout':False,
        'real_person_fidelity_verified':False,'memories':read(root / 'deliveries.private.json')['memories']}
    if not (out / 'answers.json').exists(): write_once(out / 'answers.json',predictions)
    write_once(out / 'report.json',report); return report


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--proposal',required=True);parser.add_argument('--run',action='store_true');parser.add_argument('--approval');parser.add_argument('--out');args=parser.parse_args()
    if args.run:
        if not args.approval or not args.out:parser.error('--run requires --approval and --out')
        report=execute(args.proposal,args.out,read(args.approval));print(json.dumps({'status':report['status'],'calls':report['calls'].get('execution_records')}))
    else:print(json.dumps({'proposal_id':preflight(args.proposal)['id'],'external_model_calls':0}))
