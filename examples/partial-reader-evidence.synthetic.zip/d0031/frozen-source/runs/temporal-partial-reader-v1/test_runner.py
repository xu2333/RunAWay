"""Injected fakes and subprocess interception only; never service/LLM quality tests."""
import copy
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('partial_reader', Path(__file__).with_name('runner.py'))
s = importlib.util.module_from_spec(spec); spec.loader.exec_module(s)
from runaway import taste_executor as inherited


class ReaderTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.base = Path(self.temp.name); self.plan = self.base / 'plan'; self.calls = 0
        self.runtime = s.read(ROOT / 'runs/temporal-concise-v1/proposed-reader/proposal.json')
        self.config = s.prepare(self.plan, self.runtime, count=lambda _:120)
        self.jobs = s.read(self.plan / 'jobs.json'); self.gold = s.read(self.plan / 'gold.private.json')

    def tearDown(self): self.temp.cleanup()

    def fake(self, prompt, model, **kwargs):
        self.calls += 1; self.assertEqual(model,'gpt-6.1-sol'); self.assertEqual(kwargs['timeout'],180)
        job = next(j for j in self.jobs if j['request']['prompt']==prompt)
        data = json.loads(prompt.split('\nINPUT_JSON:\n',1)[1])
        self.assertEqual(set(data),{'instruction','memory','queries','source_cutoff'})
        self.assertEqual(len(data['queries']),18); self.assertEqual(len(data['memory']),187)
        for q in data['queries']: self.assertEqual(set(q),{'id','task','question','answer_options'})
        return json.dumps({c['public']['id']:c['gold'] for c in self.gold[job['persona_id']]}), {'backend':'injected_fake_not_quality','usage':[{'input_tokens':2,'output_tokens':1}]}

    def run_fake(self, backend=None, out=None):
        with patch.object(s.generation,'codex_generate',side_effect=AssertionError('Service disabled in offline test')):
            return s.execute(self.plan,out or self.base/'out',backend=backend or self.fake,count=lambda _:120)

    def test_fixed_original_jobs_exact_payload_two_slots_and_full_denominators(self):
        self.assertEqual((self.plan/'jobs.json').read_bytes(),(ROOT/s.DESIGN/'jobs.json').read_bytes())
        r=self.run_fake();self.assertEqual(self.calls,2);self.assertEqual(r['external_model_calls'],0)
        self.assertEqual(r['backend_kind'],'injected_fake_not_model_quality');self.assertTrue(r['strict_target_passed'])
        self.assertEqual(r['stage_attempts'],{'actual_memory_reader':2});self.assertEqual(r['calls']['execution_records'],2)
        self.assertEqual(r['calls']['known_usage']['total_tokens'],6)
        c=r['scores']['current_choice'];self.assertEqual((c['correct'],c['planned'],c['missing']),(36,36,0))
        self.assertEqual(c['current_scenarios_option_orders_collapsed']['planned'],18)
        self.assertEqual(c['matched_domain_contrasts']['planned'],1);self.assertEqual(c['hard_constraints']['active_hard_queries'],4)
        self.assertEqual({k:v['planned'] for k,v in r['scores']['context_slices'].items()},{'partial_context':20,'complete_context':16})
        self.assertEqual(r['scores']['historical_reconstruction'],{'status':'not_planned_not_measured','planned':0,'correct':None})
        self.assertIsNone(r['scores']['state_preservation']['correct'])

    def test_quality_failure_is_reported_without_extra_or_repair_calls(self):
        def all_unknown(*args,**kwargs):
            raw,meta=self.fake(*args,**kwargs);return json.dumps({k:'U' for k in json.loads(raw)}),meta
        r=self.run_fake(all_unknown);self.assertEqual(self.calls,2);self.assertEqual(r['status'],'complete');self.assertFalse(r['strict_target_passed'])
        self.assertEqual(r['scores']['current_choice']['correct'],16)

    def test_first_format_failure_stops_second_and_keeps_all_missing_denominators(self):
        def malformed(*args,**kwargs):
            raw,meta=self.fake(*args,**kwargs);value=json.loads(raw);value.pop(next(iter(value)));return json.dumps(value),meta
        r=self.run_fake(malformed);self.assertEqual(self.calls,1);self.assertEqual(r['status'],'stopped')
        self.assertEqual(r['scores']['current_choice']['missing'],36)
        self.assertEqual(r['scores']['context_slices']['partial_context']['missing'],20)
        self.assertEqual(r['calls']['executions_with_usage'],1)

    def test_unknown_usage_stops_before_second_and_is_not_zero_cost(self):
        def unknown(*args,**kwargs):raw,_=self.fake(*args,**kwargs);return raw,{'backend':'injected_unknown'}
        r=self.run_fake(unknown);self.assertEqual(self.calls,1);self.assertEqual(r['status'],'stopped')
        self.assertEqual(r['calls']['executions_missing_usage'],1);self.assertEqual(r['scores']['current_choice']['missing'],36)

    def test_timeout_and_transport_failure_never_retry(self):
        for kind in ('timeout','transport'):
            with self.subTest(kind=kind):
                if (self.plan/'execution-intent.json').exists():
                    self.plan=self.base/('plan-'+kind);s.prepare(self.plan,self.runtime,count=lambda _:120)
                self.calls=0
                def failure(*args,**kwargs):
                    self.calls+=1
                    if kind=='timeout':raise s.generation.GenerationTimeout({'backend':'injected_timeout','usage':None})
                    raise ValueError('injected transport failure')
                r=self.run_fake(failure,self.base/kind);self.assertEqual(self.calls,1);self.assertEqual(r['status'],'stopped')
                self.assertEqual(r['scores']['current_choice']['missing'],36)

    def test_checkpoint_tampering_stops_after_first_with_second_missing(self):
        original=s.atomic
        def corrupt(path,value):
            original(path,value)
            if path.name=='answers.json':
                response=next((path.parent/'calls').glob('*.response.json'));response.write_text(response.read_text().replace('"sha256": "','"sha256": "bad'))
        with patch.object(s,'atomic',side_effect=corrupt):r=self.run_fake()
        self.assertEqual(self.calls,1);self.assertEqual(r['status'],'stopped');self.assertFalse(r['strict_target_passed'])
        self.assertEqual(r['scores']['current_choice']['missing'],18);self.assertTrue(r['calls']['integrity_uncertain'])

    def test_single_use_even_across_outputs_and_copy_cannot_bypass(self):
        self.run_fake()
        with self.assertRaises(FileExistsError):self.run_fake(out=self.base/'other')
        self.assertEqual(self.calls,2)
        copy_to=self.base/'copy';shutil.copytree(self.plan,copy_to)
        with self.assertRaisesRegex(ValueError,'Copied/moved'):s.preflight(copy_to)

    def test_existing_output_and_budget_drift_block_before_intent_or_backend(self):
        existing=self.base/'existing';existing.mkdir()
        with self.assertRaisesRegex(ValueError,'Existing output'):self.run_fake(out=existing)
        for counter in (lambda _:289,lambda _:121,lambda _:True):
            with self.assertRaises(ValueError):s.execute(self.plan,self.base/'blocked',backend=self.fake,count=counter)
        self.assertEqual(self.calls,0);self.assertFalse((self.plan/'execution-intent.json').exists())

    def test_approval_and_bound_acceptance_are_required_before_runtime_or_service(self):
        with patch.object(s,'runtime_check') as runtime,patch.object(s.generation,'codex_generate') as service:
            for approval in (None,{'status':'approved','proposal_id':'old','human_source':{'test':True}}):
                with self.assertRaisesRegex(ValueError,'human approval'):s.execute(self.plan,self.base/'real',approval=approval,count=lambda _:120)
            with self.assertRaisesRegex(ValueError,'offline acceptance'):
                s.execute(self.plan,self.base/'real',approval={'status':'approved','proposal_id':self.config['id'],'human_source':{'TEST_ONLY':True}},count=lambda _:120)
            runtime.assert_not_called();service.assert_not_called()
        self.assertFalse((self.plan/'execution-intent.json').exists())

    def test_runtime_drift_blocks_before_intent_even_with_simulated_accepted_evidence(self):
        path=self.base/'accepted';evidence={'status':'offline_acceptance_passed','all_checks_passed':True,'external_model_calls':0,
            'source_hashes':{n:s.sha(ROOT/n) for n in s.sources()},'runtime_local_only':self.runtime['runtime_expected'],'TEST_ONLY_NOT_REAL_ACCEPTANCE':True}
        p=s.prepare(path,self.runtime,evidence,count=lambda _:120)
        with patch.object(s,'runtime_check',return_value={'changed':True}),patch.object(s.generation,'codex_generate') as service:
            with self.assertRaisesRegex(ValueError,'runtime drifted'):
                s.execute(path,self.base/'real',approval={'status':'approved','proposal_id':p['id'],'human_source':{'TEST_ONLY':True}},count=lambda _:120)
            service.assert_not_called()
        self.assertFalse((path/'execution-intent.json').exists())

    def test_input_source_snapshot_and_archive_drift_fail_preflight(self):
        for name in s.INPUTS:
            path=self.plan/name;original=path.read_bytes()
            try:
                path.write_bytes(original+b' ')
                with self.assertRaisesRegex(ValueError,'Frozen input'):s.preflight(self.plan)
            finally:path.write_bytes(original)
        path=self.plan/'frozen-source/runaway/temporal.py';original=path.read_bytes()
        try:
            path.write_bytes(original+b'\n')
            with self.assertRaisesRegex(ValueError,'Frozen source'):s.preflight(self.plan)
        finally:path.write_bytes(original)
        real_sha=s.sha
        with patch.object(s,'sha',side_effect=lambda p:'0'*64 if Path(p).name==s.ARCHIVES[0] else real_sha(p)):
            with self.assertRaisesRegex(ValueError,'Old archive'):s.preflight(self.plan)
        self.assertEqual(self.calls,0)

    def test_old_requests_are_blocked_before_any_backend_attempt(self):
        target=self.base/'old-request';target.mkdir();backend=unittest.mock.Mock()
        calls=s.DirectCalls(target,self.config,backend);request=copy.deepcopy(self.jobs[0]['request'])
        calls.config=copy.deepcopy(self.config);calls.config['forbidden_request_ids'].append(s.digest(s.canonical(request)))
        with self.assertRaisesRegex(ValueError,'prior request'):calls.call('actual_memory_reader',request)
        backend.assert_not_called();self.assertEqual(calls.ledger['execution_records'],0)
        self.assertFalse(list((target/'calls').glob('*.request.json')))

    def test_inherited_stage_and_global_cap_reject_third_backend_entry(self):
        target=self.base/'cap';target.mkdir();calls=s.DirectCalls(target,self.config,self.fake)
        for job in self.jobs:calls.call('actual_memory_reader',job['request'])
        extra=copy.deepcopy(self.jobs[0]['request']);extra['prompt']+='\n'
        with self.assertRaisesRegex(ValueError,'Stage/global call cap'):calls.call('actual_memory_reader',extra)
        self.assertEqual(self.calls,2);self.assertEqual(calls.ledger['execution_records'],2)

    def test_optimized_python_cannot_skip_preflight(self):
        r=subprocess.run([sys.executable,'-O','-B',str(Path(__file__).with_name('runner.py')),'--proposal',str(self.plan)],capture_output=True,text=True)
        self.assertNotEqual(r.returncode,0);self.assertIn('Optimized Python is unsupported',r.stderr)

    def test_inherited_generation_builder_and_observer_keep_isolation_and_deadline(self):
        out=self.base/'observer';out.mkdir();calls=s.DirectCalls(out,self.config,self.fake)
        answer=json.dumps({'x':'U'});events='\n'.join(json.dumps(e) for e in [
            {'type':'item.completed','item':{'type':'agent_message','text':answer}},
            {'type':'turn.completed','usage':{'input_tokens':1,'output_tokens':1}}])
        def intercepted(args,prompt,timeout):
            self.assertEqual(prompt,'synthetic offline isolation probe')
            response=subprocess.CompletedProcess(args,0,events,'')
            with patch.object(inherited,'ORIGINAL_RUN_BOUNDED',return_value=response) as transport:
                result=calls.observed_runner(args,prompt,timeout)
                changes=[]
                bad=args.copy();bad.remove('--ignore-user-config');changes.append(bad)
                bad=args.copy();bad[bad.index('--sandbox')+1]='workspace-write';changes.append(bad)
                bad=args+['-c','model_reasoning_effort="low"'];changes.append(bad)
                bad=args.copy();index=bad.index('shell_tool');del bad[index-1:index+1];changes.append(bad)
                bad=args.copy();index=bad.index('memories.use_memories=false');del bad[index-1:index+1];changes.append(bad)
                for bad in changes:
                    with self.assertRaises(inherited.Stopped):calls.observed_runner(bad,prompt,timeout)
                with self.assertRaises(inherited.Stopped):calls.observed_runner(args,prompt,240)
                foreign=Path(args[args.index('-C')+1])/'foreign.txt';foreign.write_text('test-only foreign workspace file')
                try:
                    with self.assertRaises(inherited.Stopped):calls.observed_runner(args,prompt,180)
                finally:foreign.unlink()
                transport.assert_called_once();return result
        with patch.object(s.generation,'run_bounded',side_effect=intercepted),patch.object(s.generation.subprocess,'check_output',return_value='mock-cli-version'):
            raw,meta=s.generation.codex_generate('synthetic offline isolation probe','gpt-6.1-sol',schema={'type':'object'},system=s.generation.SYSTEM)
        self.assertEqual(raw,answer);self.assertEqual(meta['usage'][0]['input_tokens'],1)


if __name__=='__main__':unittest.main()
