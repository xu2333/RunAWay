import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('discrimination_runner', Path(__file__).with_name('runner.py'))
s = importlib.util.module_from_spec(spec); spec.loader.exec_module(s)


class DiscriminationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.base = Path(self.temp.name); self.plan = self.base / 'plan'; self.calls = 0
        runtime = json.loads((ROOT / 'runs/temporal-scale-v1/proposed-comparison-reviewed/proposal.json').read_text())
        s.prepare(self.plan, runtime); self.jobs = s.read(self.plan / 'jobs.json'); self.expected = s.read(self.plan / 'calibration.private.json')

    def tearDown(self): self.temp.cleanup()

    def fake(self, prompt, model, **kwargs):
        self.calls += 1; self.assertEqual(model, 'gpt-6.1-sol'); self.assertEqual(kwargs['timeout'], 180)
        job = next(j for j in self.jobs if j['request']['prompt'] == prompt)
        value = self.expected[job['stage']]['predictions'][job['persona_id']]
        payload = json.loads(prompt.split('\nINPUT_JSON:\n', 1)[1]); self.assertEqual(set(payload), {'instruction', 'memory', 'queries', 'source_cutoff'})
        return json.dumps(value), {'backend': 'fake_not_quality', 'usage': [{'input_tokens': 1, 'output_tokens': 1}]}

    def run_fake(self, backend=None, name='out'):
        with patch.object(s.generation, 'codex_generate', side_effect=AssertionError('No service allowed')):
            return s.execute(self.plan, self.base / name, backend=backend or self.fake, count=lambda _: 340)

    def test_four_new_controls_keep_denominators_and_fixed_manipulation_semantics(self):
        r = self.run_fake(); self.assertEqual(self.calls, 4); self.assertTrue(r['diagnostic_success']); self.assertEqual(r['external_model_calls'], 0)
        self.assertEqual(r['stage_attempts'], s.STAGES)
        for condition in s.STAGES:
            self.assertEqual(r['scores'][condition]['current_choice']['planned'], 112)
            self.assertEqual(r['scores'][condition]['historical_reconstruction']['planned'], 38)
            self.assertEqual(r['manipulation_semantics_concordance'][condition], {'correct': 150, 'planned': 150})
        self.assertEqual(r['prior_intact_controls_offline_not_new']['current_choice']['correct'], 112)
        self.assertLess(r['scores']['wrong_person_reader']['current_choice']['matched_domain_contrasts']['correct'], 3)

    def test_reader_ignoring_damage_and_answering_original_truth_fails_diagnostic(self):
        world = s.read(self.plan / 'world.private.json')
        def oracle(prompt, model, **kwargs):
            self.calls += 1; job = next(j for j in self.jobs if j['request']['prompt'] == prompt)
            person = next(p for p in world['people'] if p['id'] == job['persona_id'])
            return json.dumps({c['public']['id']: c['gold'] if c['public']['task'] == 'current_choice' else 'U' for c in person['cases']}), {'usage': [{'input_tokens': 1, 'output_tokens': 1}]}
        r = self.run_fake(oracle); self.assertEqual(self.calls, 4); self.assertFalse(r['diagnostic_success'])
        self.assertTrue(all(x['current_choice']['correct'] == 112 for x in r['scores'].values()))

    def test_unknown_usage_stops_all_later_and_retains_missing_denominators(self):
        def unknown(*args, **kwargs):
            raw, _ = self.fake(*args, **kwargs); return raw, {'backend': 'fake_unknown'}
        r = self.run_fake(unknown); self.assertEqual((self.calls, r['status']), (1, 'stopped'))
        self.assertEqual(r['calls']['executions_missing_usage'], 1)
        self.assertEqual(r['scores']['drop_hard_reader']['joint']['missing'], 150)

    def test_unapproved_drift_budget_and_optimized_mode_block_before_backend(self):
        with self.assertRaisesRegex(ValueError, 'human approval'): s.execute(self.plan, self.base / 'real')
        self.assertFalse((self.plan / 'execution-intent.json').exists())
        with self.assertRaises(AssertionError): s.execute(self.plan, self.base / 'budget', backend=self.fake, count=lambda _: 385)
        self.assertEqual(self.calls, 0)
        r = subprocess.run([sys.executable, '-O', '-B', str(Path(__file__).with_name('runner.py')), '--proposal', str(self.plan)], capture_output=True, text=True)
        self.assertNotEqual(r.returncode, 0); self.assertIn('Optimized Python is unsupported', r.stderr)
        path = self.plan / 'jobs.json'; path.write_text(path.read_text() + ' ')
        with self.assertRaises(AssertionError): s.preflight(self.plan)


if __name__ == '__main__': unittest.main()
