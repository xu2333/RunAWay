"""Freeze four reader-only negative controls; never execute without new approval."""
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from runaway import temporal as t, fidelity_stress as fs, generation
from runaway.card import canonical, digest
from runaway.execution_ledger import checked
from runaway.fidelity_runner import DirectCalls
from runaway.pipeline import write_once
from runaway.taste_executor import answers_checked, runtime_check, ORIGINAL_RUN_BOUNDED
from runaway.taste_plan import reader_job

STAGES = {'wrong_person_reader': 2, 'drop_hard_reader': 2}
ARCHIVES = ('pilot-evidence.synthetic.zip', 'comparison-evidence.synthetic.zip', 'stress-service-evidence.synthetic.zip', 'temporal-evidence.synthetic.zip', 'temporal-scale-evidence.synthetic.zip')
read = lambda p: json.loads(Path(p).read_text())


def semantic_predictions(world, report, condition):
    """Program reads actual event graphs, not prose. Calibration only, never LLM quality."""
    result = {}; lookup = {p['id']: p for p in world['people']}
    for person in world['people']:
        pid = person['id']; owner = person['twin'] if condition == 'wrong_person_reader' else pid
        artifact = report['artifacts'][owner]; rules = t.effective(artifact); answers = {}
        for case in person['cases']:
            if case['public']['task'] != 'current_choice':
                answers[case['public']['id']] = 'U'; continue
            key = case['key']; domain = next((d for d in fs.DOMAINS if d[0] == key), None)
            name = domain[1] if domain else fs.EXTRA[key][0]
            context = {domain[3][int(k[-1])]: v for k, v in case['context'].items()} if domain else {}
            action = None
            for tier in ('constraint', 'exception', 'regular'):
                if condition == 'drop_hard_reader' and tier == 'constraint': continue
                candidates = rules.get(name, {}).get(tier, [])
                if any(t._matches(e, context) is None for e in candidates): break
                selected = [e for e in candidates if t._matches(e, context) is True]
                if selected:
                    actions = {e['action'] for e in selected}; action = next(iter(actions)) if len(actions) == 1 else None; break
            code = 'U' if action is None else next(k for k in ('0', '1') if fs.label(key, k) == action)
            if case['instruction'] is not None: code = case['instruction']
            answers[case['public']['id']] = next(k for k, v in case['options'].items() if v == code)
        result[pid] = answers
    return result


def prior_controls(world, controls, report):
    predictions = {}
    for person, old in zip(world['people'], controls):
        pid = person['id']; job = reader_job('temporal_scale', pid, report['memories'][pid]['text'], [c['public'] for c in person['cases']], fs.READER, 12)
        assert job['request'] == old['request'] and job['request_id'] == old['request_id']
        for key in ('response', 'attempt'):
            assert old[key]['sha256'] == digest(canonical({k: v for k, v in old[key].items() if k != 'sha256'}))
            assert old[key]['request_id'] == old['request_id']
        assert old['response']['execution_id'] == old['attempt']['execution_id']
        predictions[pid] = answers_checked(old['response']['answer'], [c['public'] for c in person['cases']])
    scores = {task: fs.score(world, predictions, task) for task in ('current_choice', 'historical_reconstruction', 'joint')}
    assert scores == report['scores'] and scores['current_choice']['correct'] == 112 and scores['historical_reconstruction']['correct'] == 0
    return scores


def prepare(out, runtime):
    out = Path(out); out.mkdir(parents=True, exist_ok=False)
    with zipfile.ZipFile(ROOT / 'examples/temporal-scale-evidence.synthetic.zip') as archive:
        report = json.loads(archive.read('d0023/raw-report.synthetic.json')); world = json.loads(archive.read('d0023/world.synthetic.json')); controls = []
        for person in world['people']:
            pid = person['id']; job = reader_job('temporal_scale', pid, report['memories'][pid]['text'], [c['public'] for c in person['cases']], fs.READER, 12)
            key = job['request_id']; old = {'request_id': key}
            for part in ('request', 'response', 'attempt'):
                data = archive.read(f'd0023/calls/{key}.{part}.json'); old[part] = json.loads(data); old[part + '_bytes_sha256'] = hashlib.sha256(data).hexdigest()
            controls.append(old)
    baseline = prior_controls(world, controls, report); jobs = []; mutations = []
    for condition in STAGES:
        for person in world['people']:
            pid = person['id']; owner = person['twin'] if condition == 'wrong_person_reader' else pid
            before = report['memories'][owner]['text']; text = before
            if condition == 'drop_hard_reader':
                text, removed = re.subn(r'；硬约束若[^。\n]*', '', before)
                assert removed == 3 and len(text) < len(before)
                mutations.append({'person_id': pid, 'operation': 'Remove exactly three active hard-constraint clauses; preserve all other bytes.', 'before': before, 'after': text, 'removed_clauses': removed})
            job = reader_job(condition, pid, text, [c['public'] for c in person['cases']], fs.READER, 12)
            jobs.append({**job, 'stage': condition, 'memory_owner': owner})
    calibration = {condition: {'predictions': semantic_predictions(world, report, condition), 'kind': 'program_event_graph_calibration_not_model_quality'} for condition in ('intact', *STAGES)}
    for row in calibration.values(): row['scores'] = {task: fs.score(world, row['predictions'], task) for task in ('current_choice', 'historical_reconstruction', 'joint')}
    assert calibration['intact']['scores']['current_choice']['correct'] == 112
    assert all(calibration[k]['scores']['current_choice']['correct'] < 112 for k in STAGES)
    for n, v in {'world.private.json': world, 'jobs.json': jobs, 'source-report.synthetic.json': report, 'prior-controls.private.json': controls, 'calibration.private.json': calibration, 'mutations.json': mutations}.items(): write_once(out / n, v)
    code = [str(p.relative_to(ROOT)) for p in sorted((ROOT / 'runaway').glob('*.py'))] + ['runs/temporal-discrimination-v1/runner.py', 'runs/temporal-discrimination-v1/test_runner.py']
    inputs = ('world.private.json', 'jobs.json', 'source-report.synthetic.json', 'prior-controls.private.json', 'calibration.private.json', 'mutations.json')
    forbidden = sorted({Path(n).name.removesuffix('.request.json') for a in ARCHIVES for n in zipfile.ZipFile(ROOT / 'examples' / a).namelist() if n.endswith('.request.json')})
    assert len({j['request_id'] for j in jobs}) == 4 and not set(j['request_id'] for j in jobs) & set(forbidden)
    body = {'proposal_directory': str(out.resolve()), 'status': 'offline_not_approved_not_executed', 'calls_max': 4, 'stage_caps': STAGES, 'models': {'reader': 'gpt-6.1-sol'},
        **{k: runtime[k] for k in ('python_executable', 'tokenizer', 'tokenizer_path', 'runtime_expected')},
        'timeout_seconds': 180, 'cleanup_waits_seconds': [2, 2], 'forbidden_request_ids': forbidden,
        'selection': 'Fixed same consumed D23 paired cluster; two wrong-person memories and two exactly-three-hard-clause deletions. No new extraction, compression or resampling.',
        'data_scope': 'Only frozen actual synthetic current-memory text (swapped or explicitly damaged),75 public queries/person, existing READER/SYSTEM/schema/CLI metadata. No histories, source graphs, private event metadata, calibration/gold, old answers, real/central/workspace data in payload; credentials only authenticate.',
        'prior_controls': 'D23 intact memory responses reused offline, not new/contemporary independent controls or new costs; reader service drift remains a confound. No old request may be executed again.',
        'reporting': 'Per condition112current+38historical=150joint,56collapsed,3matched contrasts. Missing differs from U. Report source-truth scores AND concordance with fixed damaged-memory semantics; program calibration is not model evidence. Diagnostic success requires both negative conditions to fall below intact112 on current, wrong-person matched<3, and observed answers match all fixed manipulation predictions. Otherwise report a failure, never repair or omit cases.',
        'stopping': 'Any source/frozen/archive/runtime/prior-control/request/budget drift, format/transport/timeout, unknown usage or checkpoint state stops entire later batch. No quality-based early omission: preserve all4 planned calls unless a safety/integrity stop occurs.',
        'budget': 'All four full current memories must still fit768characters/384actual frozen-vocabularytokens before any call. Max4 new reader generations,180sec+2+2cleanup each, zero retries/repair/truncation/resampling, default CLI reasoning and same isolation, existing login/service, no purchases. No aggregate HTTP/token/money/time cap.',
        'inference_limit': 'One consumed pair, no new holdout, population/real/crossprovider/causal-old-new claim. Temporal separation from old baseline disclosed.',
        'source_hashes': {n: hashlib.sha256((ROOT / n).read_bytes()).hexdigest() for n in code}, 'input_hashes': {n: hashlib.sha256((out / n).read_bytes()).hexdigest() for n in inputs},
        'sealed_archives': {n: hashlib.sha256((ROOT / 'examples' / n).read_bytes()).hexdigest() for n in ARCHIVES}}
    p = {**body, 'id': digest(canonical(body))}; write_once(out / 'proposal.json', p)
    for n in code:
        dest = out / 'frozen-source' / n; dest.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(ROOT / n, dest)
    return p


def preflight(root):
    if sys.flags.optimize: raise ValueError('Optimized Python is unsupported')
    root = Path(root); p = read(root / 'proposal.json')
    assert p['id'] == digest(canonical({k: v for k, v in p.items() if k != 'id'})) and p['proposal_directory'] == str(root.resolve())
    assert p['calls_max'] == 4 and p['stage_caps'] == STAGES and p['models'] == {'reader': 'gpt-6.1-sol'}
    for n, sha in p['source_hashes'].items():
        assert hashlib.sha256((ROOT / n).read_bytes()).hexdigest() == sha == hashlib.sha256((root / 'frozen-source' / n).read_bytes()).hexdigest()
    for n, sha in p['input_hashes'].items(): assert hashlib.sha256((root / n).read_bytes()).hexdigest() == sha
    for n, sha in p['sealed_archives'].items(): assert hashlib.sha256((ROOT / 'examples' / n).read_bytes()).hexdigest() == sha
    prior_controls(read(root / 'world.private.json'), read(root / 'prior-controls.private.json'), read(root / 'source-report.synthetic.json'))
    return p


def execute(root, out, approval=None, backend=None, count=None):
    root, out = Path(root), Path(out); p = preflight(root); real = backend is None
    if real:
        if not approval or approval.get('status') != 'approved' or approval.get('proposal_id') != p['id'] or not approval.get('human_source'):
            raise ValueError('New separately verified direct human approval required')
        assert runtime_check(p) == p['runtime_expected']
    model = None
    try:
        if count is None:
            import llama_cpp
            model = llama_cpp.Llama(model_path=p['tokenizer_path'], vocab_only=True, n_gpu_layers=0, verbose=False)
            count = lambda text: len(model.tokenize(text.encode(), add_bos=False, special=False))
        budgets = [{'request_id': j['request_id'], 'characters': len(json.loads(j['request']['prompt'].split('\nINPUT_JSON:\n', 1)[1])['memory']), 'tokens': count(json.loads(j['request']['prompt'].split('\nINPUT_JSON:\n', 1)[1])['memory'])} for j in read(root / 'jobs.json')]
        assert all(b['characters'] <= 768 and type(b['tokens']) is int and 0 <= b['tokens'] <= 384 for b in budgets)
    finally:
        if model is not None: model.close()
    if real:
        fd = os.open(root / 'execution-intent.json', os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'w') as stream: json.dump({'proposal_id': p['id'], 'human_source': approval['human_source'], 'at': datetime.now(timezone.utc).isoformat()}, stream)
        backend = generation.codex_generate
    out.mkdir(parents=True, exist_ok=False); calls = DirectCalls(out, p, backend); world = read(root / 'world.private.json'); predictions = {k: {} for k in STAGES}
    generation.run_bounded = calls.observed_runner
    try:
        for job in read(root / 'jobs.json'):
            public = json.loads(job['request']['prompt'].split('\nINPUT_JSON:\n', 1)[1])['queries']
            predictions[job['stage']][job['persona_id']] = answers_checked(calls.call(job['stage'], job['request']), public)
    except Exception as error:
        if not calls.stopped: calls.stop('local_or_format_failure', error_type=type(error).__name__, error=str(error))
    finally: generation.run_bounded = ORIGINAL_RUN_BOUNDED
    try: calls.update()
    except Exception: calls.stop('uncertain_checkpoint_state')
    scores = {k: {task: fs.score(world, v, task) for task in ('current_choice', 'historical_reconstruction', 'joint')} for k, v in predictions.items()}
    expected = read(root / 'calibration.private.json'); concordance = {k: {'correct': sum(predictions[k].get(pid, {}).get(qid) == action for pid, answers in expected[k]['predictions'].items() for qid, action in answers.items()), 'planned': 150} for k in STAGES}
    success = not calls.stopped and all(scores[k]['current_choice']['correct'] < 112 and concordance[k]['correct'] == 150 for k in STAGES) and scores['wrong_person_reader']['current_choice']['matched_domain_contrasts']['correct'] < 3
    report = {'status': 'stopped' if calls.stopped else 'complete', 'proposal_id': p['id'], 'calls': calls.ledger, 'stage_attempts': dict(calls.counts), 'stop_reason': calls.reason,
        'scores': scores, 'manipulation_semantics_concordance': concordance, 'diagnostic_success': success, 'budgets': budgets,
        'prior_intact_controls_offline_not_new': prior_controls(world, read(root / 'prior-controls.private.json'), read(root / 'source-report.synthetic.json')),
        'backend_kind': 'actual_service' if real else 'injected_fake_not_model_quality', 'external_model_calls': calls.ledger['execution_records'] if real else 0,
        'paired_statistical_units': 1, 'new_holdout': False, 'real_person_fidelity_verified': False}
    write_once(out / 'answers.json', predictions); write_once(out / 'report.json', report); return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument('--proposal', required=True); parser.add_argument('--run', action='store_true'); parser.add_argument('--approval'); parser.add_argument('--out'); args = parser.parse_args()
    if args.run:
        if not args.approval or not args.out: parser.error('--run requires --approval and --out')
        r = execute(args.proposal, args.out, read(args.approval)); print(json.dumps({'status': r['status'], 'calls': r['calls']['execution_records']}))
    else: print(json.dumps({'proposal_id': preflight(args.proposal)['id'], 'external_model_calls': 0}))
