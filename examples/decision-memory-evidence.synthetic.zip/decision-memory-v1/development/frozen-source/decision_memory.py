"""Evidence-linked condition/action memory. Structural checks are not semantic proof."""
from pathlib import Path
from .card import canonical, digest, string, parse_answer
from .compression import HEADER
from .generation import codex_generate
from .pipeline import write_once
from .portable import make_expression
from .profile import STR, STRINGS, exact, object_schema, validate_profile
from .review import request

SCHEMA=object_schema({'scope':STR,'rules':{'type':'array','items':object_schema({
    'when':STR,'prefer':STR,'qualification':STR,'claim_ids':STRINGS,
    'anchors':{'type':'array','items':object_schema({'claim_id':STR,'quote':STR})}})},'unknown':STR})


def projected(profile):
    validate_profile(profile)
    return {'profile_id':profile['id'],'claims':[{k:c[k] for k in ('id','statement','basis','scope','conditions','exceptions','related_claim_ids')} for c in profile['claims']],
            'unknowns':profile['unknowns']}


def make_request(profile,budget=1000):
    ref=projected(profile)
    if type(budget) is not int or not 200<=budget<=16000:raise ValueError('budget must be 200–16000 Unicode characters')
    return request(
        'Compress only the supplied evidence-linked profile into readable condition/action branches in its language. '
        'No hypothetical test cases, hidden rules, choices or reference answers are supplied or should be invented. '
        'This is a candidate preference memory, not a command to act. Match the scope of the observations. '
        'Treat an explicitly observed choice as a choice: say what the person STILL chose when a condition changed. '
        'Do not replace a supported unchanged choice with only an epistemic negation such as "cannot infer that feedback changes the design". '
        'Preserve separately the action under the ordinary condition and the action under its exception. '
        'If a claim says the same action remained despite a changed condition, state the retained action positively. '
        'Do not replace unusual choices with conventional, safer or more agreeable choices. '
        'Keep the historical basis and scope, uncertainty, numeric conditions, exceptions and conflicts. '
        'Current user instructions override historical preference; no permission to act. '
        'Share a concise scope/uncertainty sentence once; do not repeat broad disclaimers after each rule so that they drown out the choice. '
        'Do not turn a single observation into a universal trait. Unknown domains remain unknown. '
        'Return scope, rules, unknown. Each rule has when (condition), prefer (chosen action), qualification (bounds/exception; empty if none), '
        'claim_ids and anchors. Each anchor has claim_id and quote, copied EXACTLY from that claim statement/scope/conditions/exceptions. '
        'Every supplied claim must be referenced and anchored at least once; linked claims must occur in the same rule. '
        'Do not print IDs, anchors, biography or source quotes in the rendered prose. Do not invent fixed personality axes or labels. '
        f'The complete rendered text is header + scope + rules + unknown, at most {budget} Unicode characters. '
        'Budget these rendered strings only; anchors stay private. Use concrete compact wording, not a numbered personality list.',
        {'reference':ref,'fixed_header':HEADER,'render_format':'HEADER + scope + newline + each (when + ， + prefer + 。 + qualification) + newline + unknown','budget':budget})


def render(value):
    rules=[''.join([r['when'].rstrip('，。;；'), '，',r['prefer'].rstrip('。;；'),'。',r['qualification']]) for r in value['rules']]
    return HEADER+value['scope'].strip()+'\n'+''.join(rules)+'\n'+value['unknown'].strip()+'\n'


def validate(value,profile,budget=1000):
    ref=projected(profile);exact(value,('scope','rules','unknown'),'decision memory')
    string(value['scope'],'scope',400);string(value['unknown'],'unknown',600)
    if not isinstance(value['rules'],list) or not 1<=len(value['rules'])<=30:raise ValueError('Provide 1–30 decision branches')
    claims={c['id']:c for c in ref['claims']};covered=set()
    for rule in value['rules']:
        exact(rule,('when','prefer','qualification','claim_ids','anchors'),'decision branch')
        string(rule['when'],'when',300);string(rule['prefer'],'prefer',300)
        if not isinstance(rule['qualification'],str) or len(rule['qualification'])>400:raise ValueError('Invalid qualification')
        ids=rule['claim_ids']
        if not isinstance(ids,list) or not ids or len(ids)!=len(set(ids)) or any(i not in claims for i in ids):raise ValueError('Unknown or duplicate claim reference')
        if not isinstance(rule['anchors'],list):raise ValueError('anchors must be a list')
        anchored=set()
        for a in rule['anchors']:
            exact(a,('claim_id','quote'),'anchor');cid=a['claim_id']
            if cid not in ids:raise ValueError('Anchor must refer to a claim in this branch')
            quote=string(a['quote'],'quote',16000);c=claims[cid]
            corpus=[c['statement'],c['scope'],*c['conditions'],*c['exceptions']]
            if not any(quote in text for text in corpus):raise ValueError('Anchor is not an exact profile substring')
            anchored.add(cid)
        if anchored!=set(ids):raise ValueError('Every referenced claim needs a private exact anchor')
        if any(related not in ids for cid in ids for related in claims[cid]['related_claim_ids']):raise ValueError('Linked conditions must travel together in one branch')
        covered.update(ids)
    if covered!=set(claims):raise ValueError('All claims must be covered; no silent omission')
    text=render(value)
    if len(text)>budget:raise ValueError(f'Decision memory exceeds budget: {len(text)} > {budget}; no truncation')
    return text


def compress(profile,destination,model,budget=1000,generate=codex_generate):
    if not model:raise ValueError('Choose an explicit model')
    prompt=make_request(profile,budget);out=Path(destination);out.mkdir(parents=True,exist_ok=False)
    write_once(out/'request.private.txt',prompt)
    raw,provenance=generate(prompt,model,schema=SCHEMA,system='Text-only evidence compressor. No tools or actions. Return the requested JSON.')
    value=parse_answer(raw);write_once(out/'candidate.private.json',value)
    try:text=validate(value,profile,budget)
    except ValueError as exc:
        write_once(out/'failure.private.json',{'error':str(exc),'provenance':provenance});raise
    expression=make_expression(text,profile['id'],'condition_action_candidate_v1')
    write_once(out/'portable.json',expression);write_once(out/'prompt.md',text)
    summary={'status':'candidate_unvalidated','profile_id':profile['id'],'portable_id':expression['id'],
             'characters':len(text),'tokens':None,'budget_characters':budget,'model_calls':1,'provenance':provenance,
             'claim_references_and_anchors_checked':True,'semantic_preservation_verified':False,'behavioral_fidelity_verified':False}
    write_once(out/'summary.private.json',summary);return summary
